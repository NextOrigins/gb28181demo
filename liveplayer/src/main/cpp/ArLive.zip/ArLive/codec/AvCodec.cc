/*
*  Copyright (c) 2016 The AnyRTC project authors. All Rights Reserved.
*
*  Please visit https://www.anyrtc.io for detail.
*
* The GNU General Public License is a free, copyleft license for
* software and other kinds of works.
*
* The licenses for most software and other practical works are designed
* to take away your freedom to share and change the works.  By contrast,
* the GNU General Public License is intended to guarantee your freedom to
* share and change all versions of a program--to make sure it remains free
* software for all its users.  We, the Free Software Foundation, use the
* GNU General Public License for most of our software; it applies also to
* any other work released this way by its authors.  You can apply it to
* your programs, too.
* See the GNU LICENSE file for more info.
*/
#include <rtc_base/bind.h>
#include "AvCodec.h"
#include "webrtc/rtc_base/time_utils.h"
#include "webrtc/modules/video_coding/codecs/h264/include/h264.h"
#include "webrtc/rtc_base/internal/default_socket_server.h"

static const size_t kEventMaxWaitTimeMs = 15;
static const size_t kMaxDataSizeSamples = 3840;

namespace webrtc {
A_AACEncoder::A_AACEncoder(AVCodecCallback&callback)
: callback_(callback)
, encoder_(nullptr)
, audio_record_sample_hz_(44100)
, audio_record_channels_(2)
{

}

A_AACEncoder::~A_AACEncoder(void)
{

    if (NULL != encoder_)
	{
		/*Close FAAC engine*/
		aac_encoder_close(encoder_);
		encoder_ = NULL;
	}
}

bool A_AACEncoder::Init(int sample_rate, int num_channels, int bitrate)
{
	if(encoder_)
		return false;
	audio_record_sample_hz_ = sample_rate;
	audio_record_channels_ = num_channels;
	encoder_ = aac_encoder_open(num_channels, sample_rate, sizeof(short)*8, bitrate, true);
	return true;
}

void A_AACEncoder::DeInit()
{
	if (encoder_ != NULL) {
		/*Close FAAC engine*/
		aac_encoder_close(encoder_);
		encoder_ = NULL;
	}
}

int A_AACEncoder::Encode(const void* audioSamples, const size_t nSamples, const size_t nBytesPerSample,
		const size_t nChannels, const uint32_t samplesPerSec, const uint32_t totalDelayMS)
{
	int status = 0;
	if(encoder_)
	{
		int16_t temp_output[kMaxDataSizeSamples];
		if (audio_record_sample_hz_ != samplesPerSec || audio_record_channels_ != nChannels) {

			int samples_per_channel_int = resampler_record_.Resample10Msec((int16_t*)audioSamples, samplesPerSec * nChannels,
				audio_record_sample_hz_ * audio_record_channels_, 1, kMaxDataSizeSamples, temp_output);
		}
		else {
			memcpy(temp_output, audioSamples, (audio_record_sample_hz_*audio_record_channels_*sizeof(short))/100);
		}

		unsigned int outlen = 0;
		uint32_t curtime = rtc::Time32();
		uint8_t encoded[1024];
		status = aac_encoder_encode_frame(encoder_, (uint8_t*)temp_output, (audio_record_sample_hz_*audio_record_channels_ * sizeof(short)) / 100, encoded, &outlen);
		if(outlen > 0)
		{
			//ALOGE("Encode aac len:%d", outlen);
			callback_.OnEncodeDataCallback(true, false, encoded, outlen, curtime);
		}
	}

	return status;
}

//===================================================
//* V_H264Encoder
V_H264Encoder::V_H264Encoder(AVCodecCallback&callback)
: callback_(callback)
, rtc::Thread(rtc::CreateDefaultSocketServer())
, need_keyframe_(true)
, running_(false)
, video_bitrate_(768)
, n_next_keyframe_time_(0)
, render_buffers_(new VideoRenderFrames(0))
, video_encoder_factory_(NULL)
{
	h264_.codecType = kVideoCodecH264;
	h264_.mode = webrtc::VideoCodecMode::kRealtimeVideo;
	h264_.startBitrate = video_bitrate_;
	h264_.maxBitrate = 1024;
	h264_.maxFramerate = 20;
	h264_.width = 640;
	h264_.height = 480;


}

V_H264Encoder::~V_H264Encoder(void)
{
	DestoryVideoEncoder();
}

void V_H264Encoder::SetExVideoEncoderFactory(webrtc::VideoEncoderFactory* video_encoder_factory)
{
	video_encoder_factory_ = video_encoder_factory;
}

void V_H264Encoder::SetParameter(int width, int height, int fps, int bitrate)
{
	h264_.startBitrate = bitrate;
	h264_.maxBitrate = bitrate;
	h264_.maxFramerate = fps;
	h264_.width = width;
	h264_.height = height;
}

void V_H264Encoder::UpdateBitrate(int bitrate)
{
    video_bitrate_ = bitrate;
	h264_.startBitrate = bitrate;
	h264_.maxBitrate = bitrate;
	if(encoder_ != NULL)
	{
		webrtc::VideoBitrateAllocation allocation;
		allocation.SetBitrate(0, 0, (bitrate * 1000));
		webrtc::VideoEncoder::RateControlParameters rateCtrlParams(allocation, h264_.maxFramerate);
		encoder_->SetRates(rateCtrlParams);
	}
}

void V_H264Encoder::CreateVideoEncoder()
{
	if (!running_) {
		running_ = true;
		rtc::Thread::Start();

		if (!rtc::Thread::IsCurrent()) {
			rtc::Thread::Invoke<void>(RTC_FROM_HERE, rtc::Bind(&V_H264Encoder::NewVideoEncoder, this));
		}
		else {
			NewVideoEncoder();
		}
	}
}

void V_H264Encoder::DestoryVideoEncoder()
{
	if (running_) {
		if (!rtc::Thread::IsCurrent()) {
			rtc::Thread::Invoke<void>(RTC_FROM_HERE, rtc::Bind(&V_H264Encoder::FreeVideoEncoder, this));
		}
		else {
			FreeVideoEncoder();
		}
		running_ = false;
		rtc::Thread::Stop();
	}

	{
		rtc::CritScope cs_buffer(&buffer_critsect_);
		render_buffers_.reset();
	}


}

void V_H264Encoder::RequestKeyFrame()
{
	need_keyframe_ = true;
}

void V_H264Encoder::Encode(const webrtc::VideoFrame& frame)
{
	if (!running_)
		return;

	rtc::CritScope csB(&buffer_critsect_);
	webrtc::VideoFrame video_frame(frame.video_frame_buffer(), 0, rtc::TimeMillis(), frame.rotation());
	if (render_buffers_->AddFrame(std::move(video_frame)) == 1) {
		// OK
	}
}

//* For Thread
void V_H264Encoder::Run()
{
	while(running_)
	{
		int64_t cur_time = rtc::TimeMillis();
		// Get a new frame to render and the time for the frame after this one.
		absl::optional<webrtc::VideoFrame> frame_to_render;
		uint32_t wait_time = 0;
		{
		  rtc::CritScope cs(&buffer_critsect_);
		  frame_to_render = render_buffers_->FrameToRender();
		  wait_time = render_buffers_->TimeToNextFrameRelease();
		}

		if (frame_to_render) {
			if(h264_.width != frame_to_render->width() || h264_.height != frame_to_render->height())
			{
				h264_.width = frame_to_render->width();
				h264_.height = frame_to_render->height();
				if(encoder_)
				{
					encoder_->Release();
					encoder_ = NULL;
				}

			}
			if(encoder_ == NULL)
			{
				NewVideoEncoder();
			}
			if (n_next_keyframe_time_ <= rtc::TimeUTCMillis()) {
				n_next_keyframe_time_ = rtc::TimeUTCMillis() + 3000;
				need_keyframe_ = true;
			}
			std::vector<webrtc::VideoFrameType> next_frame_types(1, webrtc::VideoFrameType::kVideoFrameDelta);
			if (need_keyframe_) {
				need_keyframe_ = false;
				next_frame_types[0] = webrtc::VideoFrameType::kVideoFrameKey;
			}

			if(encoder_)
			{
				int ret = encoder_->Encode(*frame_to_render, &next_frame_types);
				if(ret != 0)
				{
					//printf("Encode ret :%d", ret);
				}
			}
		}

		// Set timer for next frame to render.
		if (wait_time > kEventMaxWaitTimeMs) {
		  wait_time = kEventMaxWaitTimeMs;
		}
		// Reduce encode time
		uint64_t slapTime = rtc::TimeMillis() - cur_time;
		if (wait_time >= slapTime)
			wait_time -= slapTime;
		else
			wait_time = 1;
		if(wait_time > 0)
		{
			//ALOGE("WaitTime: %d", wait_time);
			rtc::Thread::SleepMs(wait_time);
		}

		rtc::Thread::ProcessMessages(1);
	}


}

webrtc::EncodedImageCallback::Result V_H264Encoder::OnEncodedImage(
	const EncodedImage& encoded_image,
	const CodecSpecificInfo* codec_specific_info)
{
	if (encoded_image._frameType == webrtc::VideoFrameType::kVideoFrameKey) {
		n_next_keyframe_time_ = rtc::TimeUTCMillis() + 3000;
	}
	callback_.OnEncodeDataCallback(false, encoded_image._frameType == webrtc::VideoFrameType::kVideoFrameKey, encoded_image.data(), encoded_image.size(), rtc::Time32());
	EncodedImageCallback::Result result(EncodedImageCallback::Result::OK);
	return result;
}

void V_H264Encoder::NewVideoEncoder()
{
	std::string strCodecName = "H264";
	webrtc::SdpVideoFormat sdpParam(strCodecName);
	sdpParam.parameters[cricket::kH264FmtpPacketizationMode] = "1";	//@Eric - 导致单帧太大?

	std::unique_ptr<VideoEncoder> extern_encoder = NULL;
	if (video_encoder_factory_ != NULL)
	{
		extern_encoder = video_encoder_factory_->CreateVideoEncoder(sdpParam);
	}
	if (extern_encoder != NULL)
	{// Try to use encoder use H/W
		if (extern_encoder->InitEncode(&h264_, 1, 0) == WEBRTC_VIDEO_CODEC_OK)
		{
			encoder_.reset(extern_encoder.release());
		}
		else
		{
			extern_encoder = NULL;
		}
	}

	if (encoder_ == NULL)
	{// Use software codec
		encoder_ = webrtc::H264Encoder::Create(cricket::VideoCodec(sdpParam));
		if (encoder_->InitEncode(&h264_, 1, 0) != WEBRTC_VIDEO_CODEC_OK)
		{
			assert(false);
		}
	}

	encoder_->RegisterEncodeCompleteCallback(this);
}

void V_H264Encoder::FreeVideoEncoder()
{
	if (encoder_ != NULL)
	{
		encoder_->Release();
		encoder_ = NULL;
	}
}

}	// namespace webrtc