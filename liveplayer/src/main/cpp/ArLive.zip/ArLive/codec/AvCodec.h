/*
*  Copyright (c) 2016 The AnyRTC project authors. All Rights Reserved.
*
*  Please visit https://www.anyrtc.io for detail.
*
* The GNU General Public License is a free, copyleft license for
* software and other kinds of works.
*
* The licenses for most software and other practical works are designed
* to take away your freedom to share and change the works.  By contrast,
* the GNU General Public License is intended to guarantee your freedom to
* share and change all versions of a program--to make sure it remains free
* software for all its users.  We, the Free Software Foundation, use the
* GNU General Public License for most of our software; it applies also to
* any other work released this way by its authors.  You can apply it to
* your programs, too.
* See the GNU LICENSE file for more info.
*/
#ifndef __AV_CODEC_H__
#define __AV_CODEC_H__
#include "webrtc/api/video_codecs/video_decoder.h"
#include "webrtc/api/video_codecs/video_encoder.h"
#include "webrtc/api/video/video_frame.h"
#include "webrtc/rtc_base/deprecated/recursive_critical_section.h"
#include "webrtc/rtc_base/thread.h"
#include "webrtc/rtc_base/thread_annotations.h"
#include "webrtc/common_video/video_render_frames.h"
#include "webrtc/modules/audio_coding/acm2/acm_resampler.h"
#include "webrtc/modules/audio_device/include/audio_device.h"
#include "webrtc/api/video_codecs/video_encoder_factory.h"
#include "webrtc/api/video_codecs/video_decoder_factory.h"
#include "pluginaac.h"

namespace webrtc {

class AVCodecCallback
{
public:
	AVCodecCallback(void){};
	virtual ~AVCodecCallback(void){};

	virtual void OnEncodeDataCallback(bool audio, bool bKeyFrame, const uint8_t *p, uint32_t length, uint32_t ts) = 0;
};

class A_AACEncoder 
{
public:
	A_AACEncoder(AVCodecCallback&callback);
	virtual ~A_AACEncoder(void);

	bool Init(int sample_rate, int num_channels, int bitrate);
	void DeInit();

	int Encode(const void* audioSamples, const size_t nSamples, const size_t nBytesPerSample, 
		const size_t nChannels, const uint32_t samplesPerSec, const uint32_t totalDelayMS);


private:
	AVCodecCallback& callback_;

	aac_enc_t	encoder_;

	webrtc::acm2::ACMResampler resampler_record_;
	int						audio_record_sample_hz_;
	int						audio_record_channels_;
};

class V_H264Encoder : public rtc::Thread, public EncodedImageCallback
{
public:
	V_H264Encoder(AVCodecCallback&callback);
	virtual ~V_H264Encoder(void);

	void SetExVideoEncoderFactory(webrtc::VideoEncoderFactory* video_encoder_factory = NULL);
	void SetParameter(int width, int height, int fps, int bitrate);
	void UpdateBitrate(int bitrate);
	void CreateVideoEncoder();
	void DestoryVideoEncoder();
	void RequestKeyFrame();
	void Encode(const webrtc::VideoFrame& frame);

	//* For Thread
	virtual void Run();

	virtual Result OnEncodedImage(
		const EncodedImage& encoded_image,
		const CodecSpecificInfo* codec_specific_info);

protected:
	void NewVideoEncoder();
	void FreeVideoEncoder();

private:
	bool		running_;
	bool		need_keyframe_;
    int         video_bitrate_;
	int64_t		n_next_keyframe_time_;
	AVCodecCallback& callback_;
	VideoCodec		h264_;
	webrtc::VideoEncoderFactory*	video_encoder_factory_;
	std::unique_ptr<VideoEncoder>	encoder_;
	rtc::RecursiveCriticalSection buffer_critsect_;
	std::unique_ptr<VideoRenderFrames> render_buffers_;
};

}	// namespace webrtc

#endif	// __AV_CODEC_H__