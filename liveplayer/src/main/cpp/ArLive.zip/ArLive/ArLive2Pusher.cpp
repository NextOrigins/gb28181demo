#include "ArLive2Pusher.h"
#include "rtc_base/bind.h"
#include "rtc_base/time_utils.h"

ArLive2Pusher::ArLive2Pusher(ArLive2Engine*pEngine)
	: ar_engine_(pEngine)
	, main_thread_(NULL)
	, event_live_push_(NULL)
	, b_live_pushed_(false)
	, b_push_paused_(false)
	, b_auto_republish_(true)
	, ar_pusher_(NULL)
	, aac_encoder_(NULL)
	, h264_encoder_(NULL)
{
	main_thread_ = pEngine;
}
ArLive2Pusher::~ArLive2Pusher(void)
{

}
void ArLive2Pusher::setVideoSource(const rtc::scoped_refptr<webrtc::VideoTrackSourceInterface>vidSource)
{
	video_source_ = vidSource;
}

void ArLive2Pusher::setExVideoEncoderFactory(webrtc::VideoEncoderFactory *video_encoder_factory) {
	exVideo_encoder_factory = video_encoder_factory;
}
//* For IArLive2Pusher
void ArLive2Pusher::setObserver(ArLivePusherObserver* observer)
{
	event_live_push_ = observer;
}
int32_t ArLive2Pusher::setEncoderMirror(bool mirror) 
{
	return 0; 
}
int32_t ArLive2Pusher::pauseAudio()
{
	return 0;
}
int32_t ArLive2Pusher::resumeAudio()
{
	return 0;
}
int32_t ArLive2Pusher::pauseVideo()
{
	return 0;
}
int32_t ArLive2Pusher::resumeVideo()
{
	return 0;
}
int ArLive2Pusher::startPush(const char* strPushUrl)
{
	if (!main_thread_->IsCurrent()) {
		return main_thread_->Invoke<int>(RTC_FROM_HERE, rtc::Bind(&ArLive2Pusher::startPush, this, strPushUrl));
	}
	if (!b_live_pushed_) {
		b_live_pushed_ = true;
		str_rtmp_url_ = strPushUrl;
		if (strstr(strPushUrl, "webrtc://") != NULL) {
			if (ar_pusher_ == NULL) {
				ar_pusher_ = createRtcPusher();
				ar_pusher_->setRtcFactory(ar_engine_->PeerConnectionFactory().get());
				ar_pusher_->setRtcVideoSource(ar_engine_->VideoSource().get());
				ar_pusher_->setObserver(this);
				ar_pusher_->startTask(strPushUrl);
			}
		}
		else {
			if (ar_pusher_ == NULL) {
				ar_pusher_ = createARPusher();
				ar_pusher_->setObserver(this);
				ar_pusher_->startTask(strPushUrl);

				initAudioWithParameters(0, 44100, 2, 64);
				initVideoWithParameters(0, 640, 480, 25, 1024);
			}
		}
	

		ar_engine_->RegisteRtcTick(this, this);
	}

	return 0;
}
int ArLive2Pusher::stopPush()
{
	if (!main_thread_->IsCurrent()) {
		return main_thread_->Invoke<int>(RTC_FROM_HERE, rtc::Bind(&ArLive2Pusher::stopPush, this));
	}

	if (b_live_pushed_) {
		b_live_pushed_ = false;
		ar_engine_->UnRegisteRtcTick(this);
		ar_engine_->DetachAudCapture(this);

		deinitVideo();

		deinitAudio();


		/*if (listener_live_push_ != NULL) {
			listener_live_push_->OnArLivePushStop(RtmpPtr());
		}*/

		if (ar_pusher_ != NULL) {
			ar_pusher_->stopTask();
			delete ar_pusher_;
			ar_pusher_ = NULL;
		}
	}
	return 0;
}
int32_t ArLive2Pusher::isPushing()
{
	return b_live_pushed_;
}
int32_t ArLive2Pusher::setAudioQuality(ArLiveAudioQuality quality)
{
	return 0;
}
int32_t ArLive2Pusher::setVideoQuality(const ArLiveVideoEncoderParam& param)
{
	return 0;
}
ITXAudioEffectManager* ArLive2Pusher::getAudioEffectManager()
{
	return NULL;
}
int32_t ArLive2Pusher::snapshot()
{
	return 0;
}
int32_t ArLive2Pusher::setWatermark(const char* watermarkPath, float x, float y, float scale)
{
	return 0;
}
int32_t ArLive2Pusher::enableVolumeEvaluation(int32_t intervalMs)
{
	return 0;
}
int32_t ArLive2Pusher::sendSeiMessage(int payloadType, const uint8_t* data, uint32_t dataSize)
{
	return 0;
}
void ArLive2Pusher::showDebugView(bool isShow)
{
	
}

//* For RtcTick
void ArLive2Pusher::OnTick()
{
	if (ar_pusher_ != NULL) {
		ar_pusher_->runOnce();
	}
}
void ArLive2Pusher::OnTickUnAttach()
{
}

//* For ArLivePushSinkInterface
void ArLive2Pusher::initAudioWithParameters(int nType, int sampleRate, int numChannels, int audBitrate)
{
	if (aac_encoder_ == NULL) {
		ar_engine_->AttachAudCapture(this);
		aac_encoder_ = new webrtc::A_AACEncoder(*this);
		aac_encoder_->Init(sampleRate, numChannels, audBitrate);
	}
}
void ArLive2Pusher::deinitAudio()
{
	if (aac_encoder_ != NULL) {
		ar_engine_->DetachAudCapture(this);
		aac_encoder_->DeInit();
		delete aac_encoder_;
		aac_encoder_ = NULL;
	}
}
void ArLive2Pusher::initVideoWithParameters(int nType, int videoWidth, int videoHeight, int videoFps, int videoBitrate)
{
	if (h264_encoder_ != NULL) {
		if (video_source_ != NULL) {
			video_source_->RemoveSink(this);
		}
		h264_encoder_->DestoryVideoEncoder();
		delete h264_encoder_;
		h264_encoder_ = NULL;
	}
	h264_encoder_ = new webrtc::V_H264Encoder(*this);
	h264_encoder_->SetParameter(videoWidth, videoHeight, videoFps, videoBitrate);
#if defined(WEBRTC_ANDROID)
	if (exVideo_encoder_factory != NULL) {
		h264_encoder_->SetExVideoEncoderFactory(exVideo_encoder_factory);
	}
#endif
	h264_encoder_->CreateVideoEncoder();
	if (video_source_ != NULL) {
		rtc::VideoSinkWants wants;
		video_source_->AddOrUpdateSink(this, wants);
	}
}
void ArLive2Pusher::deinitVideo()
{
	if (h264_encoder_ != NULL) {
		if (video_source_ != NULL) {
			video_source_->RemoveSink(this);
		}
		h264_encoder_->DestoryVideoEncoder();
		delete h264_encoder_;
		h264_encoder_ = NULL;
	}
}

//* For AudDevCaptureEvent
void ArLive2Pusher::RecordedDataIsAvailable(const void* audioSamples, const size_t nSamples,
	const size_t nBytesPerSample, const size_t nChannels, const uint32_t samplesPerSec, const uint32_t totalDelayMS)
{
	if (b_live_pushed_) {
		if (b_push_paused_) {
			memset((char*)audioSamples, 0, (samplesPerSec / 100) * nChannels * sizeof(short));
		}

		if (aac_encoder_ != NULL) {
			aac_encoder_->Encode(audioSamples, nSamples, nBytesPerSample, nChannels, samplesPerSec, totalDelayMS);
		}
	}
}

// rtc::VideoSinkInterface<webrtc::VideoFrame>
void ArLive2Pusher::OnFrame(const webrtc::VideoFrame& frame)
{
	if (b_live_pushed_) {
		if (!b_push_paused_) {
			if (h264_encoder_ != NULL) {
				h264_encoder_->Encode(frame);
			}
		}
	}
}

//* For AR::ArLivePusherObserver
void ArLive2Pusher::onError(int32_t code, const char* msg, void* extraInfo)
{
	if (event_live_push_ != NULL) {
		event_live_push_->onError(code, msg, extraInfo);
	}
}
void ArLive2Pusher::onWarning(int32_t code, const char* msg, void* extraInfo)
{
	if (event_live_push_ != NULL) {
		event_live_push_->onWarning(code, msg, extraInfo);
	}
}
void ArLive2Pusher::onPushStatusUpdate(ArLivePushStatus state, const char* msg, void* extraInfo)
{
	if (state == ArLivePushStatus::ArLivePushStatusConnectSuccess) {
		//initAudioWithParameters(0, 44100, 2, 64);
		//initVideoWithParameters(0, 640, 480, 25, 1024);
		if (h264_encoder_ != NULL) {
			h264_encoder_->RequestKeyFrame();
		}
	}
	else {
		//deinitVideo();
		//deinitAudio();
	}

	if (event_live_push_ != NULL) {
		event_live_push_->onPushStatusUpdate(state, msg, extraInfo);
	}
}
void ArLive2Pusher::onStatisticsUpdate(ArLivePusherStatistics statistics)
{
	if (event_live_push_ != NULL) {
		event_live_push_->onStatisticsUpdate(statistics);
	}
}

//* For AVCodecCallback
void ArLive2Pusher::OnEncodeDataCallback(bool audio, bool bKeyFrame, const uint8_t *pData, uint32_t nLen, uint32_t ts)
{
	if (audio)
	{
		if (ar_pusher_ != NULL) {
			ar_pusher_->setAudioData((char*)pData, nLen, ts);
		}
	}
	else
	{
		if (ar_pusher_ != NULL) {
			ar_pusher_->setVideoData((char*)pData, nLen, bKeyFrame, ts);
		}
	}
}


