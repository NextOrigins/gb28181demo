/*
*  Copyright (c) 2021 The AnyRTC project authors. All Rights Reserved.
*
*  Please visit https://www.anyrtc.io for detail.
*
* The GNU General Public License is a free, copyleft license for
* software and other kinds of works.
*
* The licenses for most software and other practical works are designed
* to take away your freedom to share and change the works.  By contrast,
* the GNU General Public License is intended to guarantee your freedom to
* share and change all versions of a program--to make sure it remains free
* software for all its users.  We, the Free Software Foundation, use the
* GNU General Public License for most of our software; it applies also to
* any other work released this way by its authors.  You can apply it to
* your programs, too.
* See the GNU LICENSE file for more info.
*/
#ifndef __AR_FF_PLAYER_H__
#define __AR_FF_PLAYER_H__
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "ARPlayer.h"
#include "rtc_base/thread.h"
#include "FFBuffer.h"
extern "C" {
#include <libavutil/avassert.h>
#include <libavutil/channel_layout.h>
#include <libavutil/opt.h>
#include <libavutil/mathematics.h>
#include <libavformat/avformat.h>
#include <libswresample/swresample.h>
}

struct UserSet
{
	UserSet(void) 
		: repeat_(false)
		, repeat_count_(0)
		, playing_(true) {};
	bool repeat_;
	int repeat_count_;
	bool playing_;
};

class ARFFPlayer : public ARPlayer, public FFBuffer, public rtc::Thread
{
public:
	ARFFPlayer(ARPlayerEvent&callback);
	virtual ~ARFFPlayer();

	int Timeout();

	//* For rtc::Thread
	virtual void Run();
	bool ReadThreadProcess();

	//* For ARPlayer
	virtual int StartTask(const char*strUrl);
	virtual void StopTask();
	virtual void RunOnce();
	virtual void Play();
	virtual void Pause();
	virtual void SetRepeat(bool bEnable);
	virtual void SetUseTcp(bool bUseTcp);
	virtual void SetNoBuffer(bool bNoBuffer);
	virtual void SetRepeatCount(int loopCount);
	virtual void SeekTo(int nSeconds);
	virtual int GetTotalDuration();
	virtual void Config(bool bAuto, int nCacheTime, int nMinCacheTime, int nMaxCacheTime, int nVideoBlockThreshold);

	//* For PlayerBuffer
	virtual void OnBufferDecodeAudioData(AVPacket* pkt);
	virtual void OnBufferDecodeVideoData(AVPacket* pkt);

	void GotAudioFrame(char* pdata, int len, int sample_hz, int channels, int64_t timestamp);

protected:
	void OpenFFDecode();
	void CloseFFDecode();

private:
	AVFormatContext *fmt_ctx_;
	int video_stream_idx_;
	int audio_stream_idx_;
	int	all_duration_;
	int cur_aud_duration_;
	int cur_vid_duration_;
	bool running_;
	bool abort_;			// �û������ж�
	bool got_eof_;			// �����з���EOF�ж�
	bool use_tcp_;
	bool net_connected_;
	bool no_buffer_;
	UserSet		user_set_;
	uint32_t	reconnect_time_;
	uint32_t	stat_time_;
	uint32_t	net_band_;
	uint32_t	conn_pkt_time_;

	rtc::RecursiveCriticalSection cs_ff_ctx_;
	AVCodecContext *video_dec_ctx_;
	AVCodecContext *audio_dec_ctx_;
	AVStream *video_stream_;
	AVStream *audio_stream_;
	AVFrame *avframe_;

	std::string		play_url_;
	AVRational		vstream_timebase_;
	AVRational		astream_timebase_;
	int64_t			ply_time_;

	//* For resample
	SwrContext *audio_convert_ctx_;
	int a_resmap_size_;
	uint8_t *a_resamp_buffer_;
	int				a_sample_hz_;
	int				a_channels_;
	char*			audio_sample_;
	int				audio_size_;
	int				a_out_sample_hz_;

private:
	char*		find_type_6_;
	int			n_type_6_;


};

#endif	// __AR_FF_PLAYER_H__