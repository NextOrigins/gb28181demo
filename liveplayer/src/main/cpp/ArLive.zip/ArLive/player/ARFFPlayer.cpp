#include "ARFFPlayer.h"
#include "rtc_base/logging.h"
#include "rtc_base/time_utils.h"
#include "rtc_base/internal/default_socket_server.h"

static uint8_t startcode[4] = { 00,00,00,01 };
#define SAMPLE_SIZE			262144
static const size_t kMaxDataSizeSamples = 3840;
static const int64_t kBitrateControllerUpdateIntervalMs = 10;
// �ڲ���������
static const AVRational TIMEBASE_MS = { 1, 1000 };


class FFContex
{
protected:
	FFContex(void){
		//av_register_all();
		avformat_network_init();

	};
public:
	static FFContex& Inst() {
		static FFContex gInst;
		return gInst;
	}
	virtual ~FFContex(void) {

		avformat_network_deinit();
	};
};

#if (defined(__APPLE__) && TARGET_OS_MAC || TARGET_OS_IPHONE)
//@derek AVMMediaType replace FFMAVMediaType
static int open_codec_context(int *stream_idx,
                              AVCodecContext **dec_ctx, AVFormatContext *fmt_ctx, enum AVMMediaType type)
#else
static int open_codec_context(int *stream_idx,
	AVCodecContext **dec_ctx, AVFormatContext *fmt_ctx, enum AVMediaType type)
#endif
{
	int ret, stream_index;
	AVStream *st;
	AVCodec *dec = NULL;
	AVDictionary *opts = NULL;

	ret = av_find_best_stream(fmt_ctx, type, -1, -1, NULL, 0);
	if (ret < 0) {
		return ret;
	}
	else {
		stream_index = ret;
		st = fmt_ctx->streams[stream_index];

		/* find decoder for the stream */
		dec = avcodec_find_decoder(st->codecpar->codec_id);
		if (!dec) {
			fprintf(stderr, "Failed to find %s codec\n",
				av_get_media_type_string(type));
			return AVERROR(EINVAL);
		}

		/* Allocate a codec context for the decoder */
		*dec_ctx = avcodec_alloc_context3(dec);
		if (!*dec_ctx) {
			fprintf(stderr, "Failed to allocate the %s codec context\n",
				av_get_media_type_string(type));
			return AVERROR(ENOMEM);
		}

		/* Copy codec parameters from input stream to output codec context */
		if ((ret = avcodec_parameters_to_context(*dec_ctx, st->codecpar)) < 0) {
			fprintf(stderr, "Failed to copy %s codec parameters to decoder context\n",
				av_get_media_type_string(type));
			return ret;
		}

		/* Init the decoders, with or without reference counting */
		av_dict_set(&opts, "refcounted_frames", "1", 0);
		if ((ret = avcodec_open2(*dec_ctx, dec, &opts)) < 0) {
			fprintf(stderr, "Failed to open %s codec\n",
				av_get_media_type_string(type));
			return ret;
		}
		*stream_idx = stream_index;
	}

	return 0;
}

static int custom_interrupt_callback(void *arg) {
	ARFFPlayer* splayer = (ARFFPlayer*)arg;
	return splayer->Timeout();
}

ARPlayer* ARP_CALL createARPlayer(ARPlayerEvent&callback)
{
	return new ARFFPlayer(callback);
}

ARFFPlayer::ARFFPlayer(ARPlayerEvent&callback)
	: ARPlayer(callback)
	, rtc::Thread(rtc::CreateDefaultSocketServer())
	, fmt_ctx_(NULL)
	, video_stream_idx_(-1)
	, audio_stream_idx_(-1)
	, all_duration_(0)
	, cur_aud_duration_(0)
	, cur_vid_duration_(0)
	, running_(false)
	, abort_(false)
	, got_eof_(false)
	, use_tcp_(false)
	, net_connected_(false)
	, no_buffer_(false)
	, reconnect_time_(0)
	, stat_time_(0)
	, net_band_(0)
	, conn_pkt_time_(0)
	, video_dec_ctx_(NULL)
	, audio_dec_ctx_(NULL)
	, avframe_(NULL)
	, audio_convert_ctx_(NULL)
	, ply_time_(0)
	, a_resamp_buffer_(NULL)
	, a_resmap_size_(0)
	, a_sample_hz_(0)
	, a_channels_(0)
	, audio_sample_(NULL)
	, audio_size_(0)
	, a_out_sample_hz_(0)
	, find_type_6_(NULL)
	, n_type_6_(0)
{
	audio_sample_ = new char[SAMPLE_SIZE];

	FFContex::Inst();
}

ARFFPlayer::~ARFFPlayer()
{
	StopTask();

	delete[] audio_sample_;
}

int ARFFPlayer::Timeout()
{
	/*if (read_pkt_time_ != 0 && read_pkt_time_ <= rtc::Time32()) {
		return EAGAIN;
	}*/
	if ((conn_pkt_time_ != 0 &&conn_pkt_time_ <= rtc::Time32()) || abort_) {
		return AVERROR_EOF;
	}

	return 0;
}

//* For rtc::Thread
void ARFFPlayer::Run()
{
	int ret = 0;

	while (running_) {
		if (fmt_ctx_ == NULL) {
			if (reconnect_time_ != 0 && reconnect_time_ <= rtc::Time32()) {
				reconnect_time_ = rtc::Time32() + 1500;
				callback_.OnArPlyStart(this);
			}
			else {
				rtc::Thread::SleepMs(1);
				continue;
			}
			OpenFFDecode();
			if (fmt_ctx_ != NULL) {
				callback_.OnArPlyOK(this);
			}
		}
		else {
			ReadThreadProcess();
		}

		if (stat_time_ <= rtc::Time32() && net_connected_) {
			stat_time_ = rtc::Time32() + 1000;
			//callback_.OnArPlyStatus(lst_size * 20, net_band_*(8 + 1));
			net_band_ = 0;
		}
		rtc::Thread::SleepMs(5);
	}

	CloseFFDecode();
	callback_.OnArPlyClose(this, 0);
}

bool ARFFPlayer::ReadThreadProcess()
{
	int ii = 0;
	if (got_eof_)
	{
		if (FFBuffer::BufferIsEmpty()) {
			CloseFFDecode();
			callback_.OnArPlyClose(this, 0);

			reconnect_time_ = 0;
			if (user_set_.repeat_ || user_set_.repeat_count_ > 0) {
				if (user_set_.repeat_count_ > 0) {
					user_set_.repeat_count_--;
				}
				reconnect_time_ = rtc::Time32();
			}
		}
		else if (!FFBuffer::IsPlaying()) {
			//* �������EOF�˲��һ�������ֹͣ���ţ���ʱӦ����ջ��壬�����޷���������
			FFBuffer::DoClear();
		}
		return false;
	}
	while (FFBuffer::NeedMoreData())
	{
		if (fmt_ctx_ != NULL) {
			int ret = 0;
			ii++;
			{
				AVPacket *packet = new AVPacket();
				av_init_packet(packet);
				packet->data = NULL;
				packet->size = 0;
				//conn_pkt_time_ = rtc::Time32() + 15000;
				conn_pkt_time_ = 0;	// ��ȡ���ݵ�ʱ�����ó�ʱ������m3u8��һֱ�ȴ������ϻ���ɲ��ſ���
				/* read frames from the file */
				if ((ret = av_read_frame(fmt_ctx_, packet)) >= 0) {
					net_band_ += packet->size;
					if (packet->stream_index == video_stream_idx_) {
						int64_t pts = 0;
						if (packet->flags & AV_PKT_FLAG_KEY) {

						}
						if (packet->dts != 0) {
							pts = av_rescale_q(packet->dts, vstream_timebase_, TIMEBASE_MS);
						}
						else {
							pts = av_rescale_q(packet->pts, vstream_timebase_, TIMEBASE_MS);
						}
						if (no_buffer_) {
							OnBufferDecodeVideoData(packet);
							av_packet_unref(packet);
							delete packet;
						}
						else {
							FFBuffer::RecvVideoData(packet, pts, pts, av_rescale_q(packet->duration, vstream_timebase_, TIMEBASE_MS));
						}
					}
					else {
						int64_t pts = 0;
						if (packet->dts != 0) {
							pts = av_rescale_q(packet->dts, astream_timebase_, TIMEBASE_MS);
						}
						else {
							pts = av_rescale_q(packet->pts, astream_timebase_, TIMEBASE_MS);
						}
						if (no_buffer_) {
							OnBufferDecodeAudioData(packet);
							av_packet_unref(packet);
							delete packet;
						}
						else {
							FFBuffer::RecvAudioData(packet, pts, pts, av_rescale_q(packet->duration, astream_timebase_, TIMEBASE_MS));
						}
					}
				}
				else {
					delete packet;
					if (ret == AVERROR_EOF) {
						got_eof_ = true;
						return false;
					}
				}
			}

			if (ii > 5) {//* �߳�ִ��ʱ�� (windows����ʵʱ����ϵͳ)����sleep ��������Ҳ����15ms���ҡ����Ե��ζ�ȡ��Ҫ��һ�㣬����ᵼ��FFMpeg�Ļ��岻�ܼ�ʱ���������¿���
				break;
			}
		}
		else {
			break;
		}
	}
	return true;
}

int ARFFPlayer::StartTask(const char*strUrl)
{
	play_url_ = strUrl;
	if (!running_) {
		abort_ = false;
		ply_time_ = 0;
		running_ = true;
		reconnect_time_ = rtc::Time32();
		user_set_.playing_ = true;
		rtc::Thread::SetName("ARFFPlayer", this);
		rtc::Thread::Start();
	}

	return 0;
}

void ARFFPlayer::RunOnce()
{
	FFBuffer::DoTick();

	if (callback_.OnArPlyNeedMoreAudioData(this)) {
		FFBuffer::DoDecodeAudio();
	}
	if (callback_.OnArPlyNeedMoreVideoData(this)) {
		FFBuffer::DoDecodeVideo();
	}
}
void ARFFPlayer::StopTask()
{
	if (running_) {
		running_ = false;
		abort_ = true;
		reconnect_time_ = 0;
		user_set_.repeat_ = false;
		rtc::Thread::Stop();
	}

	FFBuffer::DoClear();
}

void ARFFPlayer::Play()
{
	user_set_.playing_ = true;
}
void ARFFPlayer::Pause()
{
	user_set_.playing_ = false;
}
void ARFFPlayer::SetRepeat(bool bEnable)
{
	user_set_.repeat_ = bEnable;
}
void ARFFPlayer::SetUseTcp(bool bUseTcp)
{
	use_tcp_ = bUseTcp;
}
void ARFFPlayer::SetNoBuffer(bool bNoBuffer)
{
	no_buffer_ = bNoBuffer;
}
void ARFFPlayer::SetRepeatCount(int loopCount)
{
	user_set_.repeat_count_ = 0;
	if (loopCount < 0) {
		SetRepeat(true);
	}
	else if(loopCount >= 0){
		user_set_.repeat_count_ = loopCount;
	}
}
void ARFFPlayer::SeekTo(int nSeconds)
{

}
int ARFFPlayer::GetTotalDuration()
{
	return all_duration_;
}
void ARFFPlayer::Config(bool bAuto, int nCacheTime, int nMinCacheTime, int nMaxCacheTime, int nVideoBlockThreshold)
{
	FFBuffer::SetPlaySetting(bAuto, nCacheTime, nMinCacheTime, nMaxCacheTime, nVideoBlockThreshold);
}

//* For FFBuffer
void ARFFPlayer::OnBufferDecodeAudioData(AVPacket* aud_packet)
{
	AVPacket &pkt = *aud_packet;
	uint8_t*ptr = pkt.data;
	int len = pkt.size;
	int frameFinished = 0;

	//ply_time_ = av_rescale_rnd(pkt.pts, audio_stream_->time_base.den, audio_dec_ctx_->time_base.den, AV_ROUND_NEAR_INF);
	//int64_t audTime = av_rescale_rnd(pkt.pts, audio_stream_->time_base.den, audio_dec_ctx_->time_base.den, AV_ROUND_NEAR_INF);
	//printf("AudTime: %lld plyTime: %lld\r\n", audTime, ply_time_);
	{
		rtc::CritScope l(&cs_ff_ctx_);
		if (audio_dec_ctx_ != NULL) {
#if 0
			int ret = avcodec_decode_audio4(audio_dec_ctx_, avframe_, &frameFinished, &pkt);
#else
			int ret = avcodec_send_packet(audio_dec_ctx_, &pkt);
			if (ret < 0) {
				RTC_LOG(LS_ERROR) << "avcodec_send_packet error: " << ret;
			}
			else {
				ret = avcodec_receive_frame(audio_dec_ctx_, avframe_);
				if (ret < 0) {
					RTC_LOG(LS_ERROR) << "avcodec_receive_frame error: " << ret;
				}
				else {
					frameFinished = 1;
				}
			}
#endif 
			if (ret >= 0) {
				int64_t pts = 0;
				if (frameFinished) {
					int out_channels = av_get_channel_layout_nb_channels(audio_dec_ctx_->channel_layout);
					int need_size = (a_out_sample_hz_* out_channels * sizeof(int16_t)) / 100;
					//avframe_->pts = av_rescale_q(av_frame_get_best_effort_timestamp(avframe_), astream_timebase_, TIMEBASE_MS);
					avframe_->pts = av_rescale_q(avframe_->best_effort_timestamp, astream_timebase_, TIMEBASE_MS);
					//RTC_LOG(LS_ERROR) << "Audio pts: " << pkt.pts;
					pts = avframe_->pts;
					/* if a frame has been decoded, output it */
					int data_size = av_get_bytes_per_sample(audio_dec_ctx_->sample_fmt);
					if (data_size > 0) {
						int samples = swr_convert(audio_convert_ctx_, &a_resamp_buffer_, a_resmap_size_, (const uint8_t **)avframe_->data, avframe_->nb_samples);
						if (samples > 0) {
							int resampled_data_size = samples * out_channels  * av_get_bytes_per_sample(AV_SAMPLE_FMT_S16);//ÿ���������� x ������ x ÿ�������ֽ���   

							memcpy(audio_sample_ + audio_size_, a_resamp_buffer_, resampled_data_size);
							pts -= (audio_size_ * 10) / need_size;
							audio_size_ += resampled_data_size;
						}
					}
					av_frame_unref(avframe_);

					while (audio_size_ >= need_size) {
						GotAudioFrame(audio_sample_, need_size, a_out_sample_hz_, out_channels, pts);
						pts += 10;
						audio_size_ -= need_size;
						if (audio_size_ > 0) {
							memmove(audio_sample_, audio_sample_ + need_size, audio_size_);
						}
					}
				}
			}
			else {
				char errBuf[1024] = { 0 };
				av_strerror(ret, errBuf, 1024);
			}
		}
	}
}
void ARFFPlayer::OnBufferDecodeVideoData(AVPacket* vid_packet)
{
	rtc::CritScope l(&cs_ff_ctx_);
	if (video_dec_ctx_ != NULL) {
		{//* Decode?
			int frameFinished = 0;
#if 0
			int ret = avcodec_decode_video2(video_dec_ctx_, avframe_, &frameFinished, vid_packet);
#else
			int ret = avcodec_send_packet(video_dec_ctx_, vid_packet);
			if (ret < 0) {
				RTC_LOG(LS_ERROR) << "avcodec_send_packet error: " << ret;
			}
			else {
				ret = avcodec_receive_frame(video_dec_ctx_, avframe_);
				if (ret < 0) {
					RTC_LOG(LS_ERROR) << "avcodec_receive_frame error: " << ret;
				}
				else {
					frameFinished = 1;
				}
			}
#endif
			if (ret >= 0) {
				if (frameFinished) {
					//avframe_->pts = av_rescale_q(av_frame_get_best_effort_timestamp(avframe_), vstream_timebase_, TIMEBASE_MS);
					avframe_->pts = av_rescale_q(avframe_->best_effort_timestamp, vstream_timebase_, TIMEBASE_MS);
					if (no_buffer_) {
						avframe_->pts = 0;
					}
					callback_.OnArPlyVideo(this, avframe_->format, avframe_->width, avframe_->height, avframe_->data, avframe_->linesize, avframe_->pts);
				}
			}
		}
	}
}

void ARFFPlayer::GotAudioFrame(char* pdata, int len, int sample_hz, int channels, int64_t timestamp)
{
#if 0
	static FILE* gFp = NULL;
	if (gFp == NULL) {
		gFp = fopen("wav1.pcm", "wb");
	}
	if (gFp != NULL) {
		fwrite(pdata, 1, len, gFp);
	}
#endif
	callback_.OnArPlyAudio(this, pdata, sample_hz, channels, timestamp);
}

void ARFFPlayer::OpenFFDecode()
{
	rtc::CritScope l(&cs_ff_ctx_);
	if (fmt_ctx_ == NULL) {
		fmt_ctx_ = avformat_alloc_context();
		fmt_ctx_->interrupt_callback.callback = custom_interrupt_callback;
		fmt_ctx_->interrupt_callback.opaque = this;

		int ret = 0;
		/* open input file, and allocate format context */
		conn_pkt_time_ = rtc::Time32() + 10000;
		AVDictionary* options = NULL;
		av_dict_set(&options, "nobuffer", "1", 0);
		if (play_url_.find("rtmp://") != std::string::npos) {
			av_dict_set(&options, "timeout", NULL, 0);
		}
		if (play_url_.find("rtsp://") != std::string::npos) {
			if (use_tcp_) {
				av_dict_set(&options, "rtsp_transport", "tcp", 0);
			}
			else {
				av_dict_set(&options, "rtsp_transport", "udp", 0);
			}
			av_dict_set(&options, "timeout", NULL, 0);
		}
		if ((ret = avformat_open_input(&fmt_ctx_, play_url_.c_str(), NULL, &options)) < 0) {
			char strErr[1024];
			av_strerror(ret, strErr, 1024);
			printf("Could not open source (%d) url %s\n", ret, play_url_.c_str());
			return;
		}
		all_duration_ = fmt_ctx_->duration / 1000000;	//duration��λ��us��ת��Ϊ��
		cur_aud_duration_ = 0;
		cur_vid_duration_ = 0;
        fmt_ctx_->probesize = 128 *1024;
        fmt_ctx_->max_analyze_duration = 1 * AV_TIME_BASE;
		//��avformat_find_stream_info�����У����ж�AVFMT_FLAG_NOBUFFER�����Ƿ���ӵ�buffer��
		//fmt_ctx_->flags |= AVFMT_FLAG_NOBUFFER;
		//fmt_ctx_->flags |= AVFMT_FLAG_DISCARD_CORRUPT;
		/* retrieve stream information */
		if (avformat_find_stream_info(fmt_ctx_, NULL) < 0) {
			printf("Could not find stream information\n");
			avformat_close_input(&fmt_ctx_);
			fmt_ctx_ = NULL;
			return;
		}

		if (open_codec_context(&video_stream_idx_, &video_dec_ctx_, fmt_ctx_, AVMEDIA_TYPE_VIDEO) >= 0) {
			video_stream_ = fmt_ctx_->streams[video_stream_idx_];
			vstream_timebase_ = fmt_ctx_->streams[video_stream_idx_]->time_base;
		}
        else {
            video_stream_idx_ = -1;
        }

		if (open_codec_context(&audio_stream_idx_, &audio_dec_ctx_, fmt_ctx_, AVMEDIA_TYPE_AUDIO) >= 0) {
			audio_stream_ = fmt_ctx_->streams[audio_stream_idx_];
			astream_timebase_ = fmt_ctx_->streams[audio_stream_idx_]->time_base;

			a_sample_hz_ = audio_dec_ctx_->sample_rate;
			a_channels_ = audio_dec_ctx_->channels;
			a_out_sample_hz_ = 48000;// a_sample_hz_
			/*if (audio_dec_ctx_->channel_layout == 0) {
				audio_dec_ctx_->channel_layout = AV_CH_LAYOUT_MONO;
			}*/
			//@Bug: FFMPEG ����WAV ��ȡ��������
			if (audio_dec_ctx_->channels > 0 && audio_dec_ctx_->channel_layout == 0) { //��������û���������֣�����Ҫ������������
				audio_dec_ctx_->channel_layout = av_get_default_channel_layout(audio_dec_ctx_->channels);//������������
			}
			else if (audio_dec_ctx_->channels == 0 && audio_dec_ctx_->channel_layout > 0) {//����������û��������������Ҫ����������
				audio_dec_ctx_->channels = av_get_channel_layout_nb_channels(audio_dec_ctx_->channel_layout);
			}
			//Swr  
			audio_convert_ctx_ = swr_alloc();
			audio_convert_ctx_ = swr_alloc_set_opts(audio_convert_ctx_, audio_dec_ctx_->channel_layout, AV_SAMPLE_FMT_S16, a_out_sample_hz_,
				audio_dec_ctx_->channel_layout, audio_dec_ctx_->sample_fmt, audio_dec_ctx_->sample_rate, 0, NULL);//����Դ��Ƶ������Ŀ����Ƶ���� 
			swr_init(audio_convert_ctx_);
			int frame_size = (audio_dec_ctx_->frame_size == 0 ? 4096 : audio_dec_ctx_->frame_size) * 8;
			a_resmap_size_ = av_samples_get_buffer_size(NULL, av_get_channel_layout_nb_channels(audio_dec_ctx_->channel_layout), frame_size, AV_SAMPLE_FMT_S16, 1);//����ת�������ݴ�С  
			a_resamp_buffer_ = (uint8_t *)av_malloc(a_resmap_size_);//�������������  
		}
        else {
            audio_stream_idx_ = -1;
        }

		/* dump input information to stderr */
		av_dump_format(fmt_ctx_, 0, play_url_.c_str(), 0);

		if (avframe_ == NULL) {
			avframe_ = av_frame_alloc();
		}

		net_connected_ = true;
		got_eof_ = false;
	}
}
void ARFFPlayer::CloseFFDecode()
{
	net_connected_ = false;
	FFBuffer::DoClear();

	rtc::CritScope l(&cs_ff_ctx_);
	if (video_dec_ctx_ != NULL) {
		avcodec_close(video_dec_ctx_);
		video_dec_ctx_ = NULL;
	}
	if (audio_dec_ctx_ != NULL) {
		avcodec_close(audio_dec_ctx_);
		audio_dec_ctx_ = NULL;
	}

	if (fmt_ctx_ != NULL) {
		avformat_close_input(&fmt_ctx_);
		fmt_ctx_ = NULL;
	}

	if (avframe_ != NULL) {
		av_frame_free(&avframe_);
		avframe_ = NULL;
	}
	if (audio_convert_ctx_ != NULL) {
		swr_free(&audio_convert_ctx_);
		audio_convert_ctx_ = NULL;
	}
}
