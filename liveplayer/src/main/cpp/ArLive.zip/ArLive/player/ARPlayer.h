/*
*  Copyright (c) 2021 The AnyRTC project authors. All Rights Reserved.
*
*  Please visit https://www.anyrtc.io for detail.
*
* The GNU General Public License is a free, copyleft license for
* software and other kinds of works.
*
* The licenses for most software and other practical works are designed
* to take away your freedom to share and change the works.  By contrast,
* the GNU General Public License is intended to guarantee your freedom to
* share and change all versions of a program--to make sure it remains free
* software for all its users.  We, the Free Software Foundation, use the
* GNU General Public License for most of our software; it applies also to
* any other work released this way by its authors.  You can apply it to
* your programs, too.
* See the GNU LICENSE file for more info.
*/
#ifndef __ARP_PLAYER_H__
#define __ARP_PLAYER_H__
#include "ARDef.h"

class ARPlayerEvent
{
public:
	ARPlayerEvent(void) {};
	virtual ~ARPlayerEvent(void) {};

	virtual void OnArPlyOK(void*player) {};
	virtual void OnArPlyStatus(void*player, int cacheTime, int curBitrate) {};
	virtual void OnArPlyStart(void*player) {};
	virtual void OnArPlyCache(void*player, int time) {};
	virtual void OnArPlyClose(void*player,int nErrCode) {};

	virtual bool OnArPlyNeedMoreAudioData(void*player) { return true; };
	virtual bool OnArPlyNeedMoreVideoData(void*player) { return true; };
	virtual void OnArPlyAudio(void*player, const char*pData, int nSampleHz, int nChannels, int64_t pts) {};
	virtual void OnArPlyVideo(void*player, int fmt, int ww, int hh, uint8_t**pData, int*linesize, int64_t pts) {};
};

class ARPlayer
{
public:
	ARPlayer(ARPlayerEvent&callback) :callback_(callback) {};
	virtual ~ARPlayer(void) {};

	virtual int StartTask(const char*strUrl) = 0;
	virtual void StopTask() = 0;

	virtual void RunOnce() = 0;
	virtual void Play() = 0;
	virtual void Pause() = 0;
	// true: repeat
	virtual void SetRepeat(bool bEnable) = 0;
	virtual void SetUseTcp(bool bUseTcp) = 0;
	virtual void SetNoBuffer(bool bNoBuffer) = 0;
	// -1: loop forever >=0 repeat count
	virtual void SetRepeatCount(int loopCount) = 0;
	virtual void SeekTo(int nSeconds) = 0;
	virtual int GetTotalDuration() = 0;

	virtual void setRtcFactory(void* ptr) {};

	virtual void Config(bool bAuto, int nCacheTime, int nMinCacheTime, int nMaxCacheTime, int nVideoBlockThreshold) = 0;

protected:
	ARPlayerEvent&callback_;
};


ARP_API ARPlayer* ARP_CALL createARPlayer(ARPlayerEvent&callback);

ARP_API ARPlayer* ARP_CALL createRtcPlayer(ARPlayerEvent& callback);

#endif	// __ARP_PLAYER_H__
