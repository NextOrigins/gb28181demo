#include "ArLive2Player.h"
#include "third_party/libyuv/include/libyuv.h"
#include "api/video/video_frame.h"
#include "rtc_base/bind.h"
#include "rtc_base/time_utils.h"


static const size_t kMaxDataSizeSamples = 3840;
//=========================================================
ArLive2Player::ArLive2Player(ArLive2Engine*pEngine, const char*playerId)
	: ar_engine_(pEngine)
	, observer_(NULL)
	, main_thread_(pEngine->GetThread())
	, ar_player_(NULL)
	, b_play_ok_(false)
	, b_shutdown_(false)
	, audio_cache_(NULL)
	, a_cache_len_(0)
	, aac_sample_hz_(44100)
	, aac_channels_(2)
	, aac_frame_per10ms_size_(0)
{
	str_player_id_ = playerId;
	audio_cache_ = new uint8_t[kMaxDataSizeSamples * 2];
	aac_frame_per10ms_size_ = (aac_sample_hz_ / 100) * sizeof(int16_t) * aac_channels_;

}
ArLive2Player::~ArLive2Player(void)
{
	if (ar_player_ != NULL) {
		ar_player_->StopTask();
		delete ar_player_;
		ar_player_ = NULL;
	}

	delete[] audio_cache_;
}

//* For AR::IArLivePlayer
void ArLive2Player::setObserver(AR::ArLivePlayerObserver* observer)
{
	observer_ = observer;
}
int32_t ArLive2Player::setRenderView(void* view)
{
	VideoCanvas vidCanvas;
	vidCanvas.view = view;
	vidCanvas.uid = str_player_id_.c_str();
	ar_engine_->setPlayRenderView(str_player_id_.c_str(), vidCanvas);
	return ArLIVE_OK;
}
int32_t ArLive2Player::setRenderRotation(ArLiveRotation rotation)
{
	ar_engine_->setPlayRenderRotation(str_player_id_.c_str(), rotation);
	return ArLIVE_OK;
}
int32_t ArLive2Player::setRenderFillMode(ArLiveFillMode mode)
{
	ar_engine_->setPlayRenderFillMode(str_player_id_.c_str(), mode);
	return ArLIVE_OK;
}
int32_t ArLive2Player::startPlay(const char* strPlayUrl)
{
	if (!main_thread_->IsCurrent()) {
		return main_thread_->Invoke<int>(RTC_FROM_HERE, rtc::Bind(&ArLive2Player::startPlay, this, strPlayUrl));
	}
	if (strPlayUrl == NULL || strlen(strPlayUrl) == 0) {
		return -1;
	}

	if (ar_player_ == NULL) {
		if (strstr(strPlayUrl, "webrtc://") != NULL) {
			ar_player_ = createRtcPlayer(*this);
			ar_player_->setRtcFactory(ar_engine_->PeerConnectionFactory().get());
		}
		else {
			ar_player_ = createARPlayer(*this);
		}
		ar_player_->Config(ar_play_conf_.bAuto, ar_play_conf_.nCacheTime, ar_play_conf_.nMinCacheTime, ar_play_conf_.nMaxCacheTime, ar_play_conf_.nVideoBlockThreshold);
		ar_player_->SetRepeat(true);
		ar_player_->SetUseTcp(1);
		ar_player_->StartTask(strPlayUrl);

		//ar_engine_->RegisteRtcTick(this, this);
		ar_engine_->AttachAudSpeaker(this);
	}
	return 0;
}
int32_t ArLive2Player::stopPlay()
{
	bool isNeedClearLastImg = true;
	if (!main_thread_->IsCurrent()) {
		return main_thread_->Invoke<int>(RTC_FROM_HERE, rtc::Bind(&ArLive2Player::stopPlay, this));
	}

	if (ar_player_ != NULL) {
		ar_engine_->DetachAudSpeaker(this);
		ar_player_->StopTask();
		delete ar_player_;
		ar_player_ = NULL;
	}

	PlayBuffer::DoClear();

	return 0;
}
int32_t ArLive2Player::isPlaying(){return 0;}
int32_t ArLive2Player::pauseAudio(){return 0;}
int32_t ArLive2Player::resumeAudio(){return 0;}
int32_t ArLive2Player::pauseVideo(){return 0;}
int32_t ArLive2Player::resumeVideo(){return 0;}
int32_t ArLive2Player::setPlayoutVolume(int32_t volume){return 0;}
int32_t ArLive2Player::setCacheParams(float minTime, float maxTime)
{
	ar_play_conf_.nMinCacheTime = minTime;
	ar_play_conf_.nMinCacheTime = maxTime;
	return 0;
}
int32_t ArLive2Player::enableVolumeEvaluation(int32_t intervalMs){return 0;}
int32_t ArLive2Player::snapshot(){return 0;}
int32_t ArLive2Player::enableCustomRendering(bool enable, AR::ArLivePixelFormat pixelFormat, AR::ArLiveBufferType bufferType){return 0;}
int32_t ArLive2Player::enableReceiveSeiMessage(bool enable, int payloadType){return 0;}
void ArLive2Player::showDebugView(bool isShow){}

//* For RtcTick
void ArLive2Player::OnTick()
{
	//play_buffer_.DoTick();
}
void ArLive2Player::OnTickUnAttach()
{

}

//* For PlayBuffer
void ArLive2Player::OnBufferVideoRender(VideoData *videoData, int64_t pts)
{
	if (videoData->video_frame_ != nullptr) {
		const webrtc::VideoFrame render_frame(videoData->video_frame_, webrtc::VideoRotation::kVideoRotation_0, rtc::TimeMicros());

		ar_engine_->GetMgrRender().DoRenderFrame(str_player_id_.c_str(), render_frame);
	}
}
void ArLive2Player::OnFirstVideoDecoded()
{
#if 0
	if (listener_live_play_ != NULL) {
		listener_live_play_->onPlayFirstVideoFrameDecoded();
	}
#endif
}
void ArLive2Player::OnFirstAudioDecoded()
{
#if 0
	if (listener_live_play_ != NULL) {
		listener_live_play_->onPlayFirstAudioFrameDecoded();
	}
#endif
}
//* For AudDevSpeakerEvent
int ArLive2Player::MixAudioData(bool mix, void* audioSamples, uint32_t samplesPerSec, int nChannels)
{
	if (ar_player_ != NULL) {
		ar_player_->RunOnce();
	}
	return PlayBuffer::DoRender(mix, audioSamples, samplesPerSec, nChannels);
}

//* For ARPlayerEvent
void ArLive2Player::OnArPlyOK(void*player) {};
void ArLive2Player::OnArPlyStatus(void*player, int cacheTime, int curBitrate) {};
void ArLive2Player::OnArPlyStart(void*player) {};
void ArLive2Player::OnArPlyCache(void*player, int time) {};
void ArLive2Player::OnArPlyClose(void*player, int errcode) {};

bool ArLive2Player::OnArPlyNeedMoreAudioData(void*player)
{
	return PlayBuffer::NeedMoreAudioPlyData();
}
bool ArLive2Player::OnArPlyNeedMoreVideoData(void*player)
{
	return PlayBuffer::NeedMoreVideoPlyData();
}
void ArLive2Player::OnArPlyAudio(void*player, const char*pData, int nSampleHz, int nChannels, int64_t pts)
{
	PcmData *audioData = new PcmData((char*)pData, (nSampleHz / 100)*nChannels * sizeof(short), nSampleHz, nChannels);
	audioData->pts_ = pts;
	PlayBuffer::PlayAudioData(audioData);
};
void ArLive2Player::OnArPlyVideo(void*player, int fmt, int ww, int hh, uint8_t**pData, int*linesize, int64_t pts)
{
	rtc::CritScope l(&cs_render_frame_);
	if (i420_render_frame_ == NULL || (i420_render_frame_->width() != ww || i420_render_frame_->height() != hh)) {
		i420_render_frame_ = webrtc::I420Buffer::Create(ww, hh);
	}

	uint8_t* dataY = (uint8_t*)pData[0];
	uint8_t* dataU = (uint8_t*)pData[1];
	uint8_t* dataV = (uint8_t*)pData[2];
	libyuv::I420Copy(dataY, linesize[0], dataU, linesize[1], dataV, linesize[2],
		(uint8_t*)i420_render_frame_->DataY(), i420_render_frame_->StrideY(), (uint8_t*)i420_render_frame_->DataU(), i420_render_frame_->StrideU(),
		(uint8_t*)i420_render_frame_->DataV(), i420_render_frame_->StrideV(), i420_render_frame_->width(), i420_render_frame_->height());

	VideoData *videoData = new VideoData();
	videoData->video_frame_ = i420_render_frame_;
	videoData->pts_ = pts;
	PlayBuffer::PlayVideoData(videoData);
#if 0
	static FILE*gFp = NULL;
	if (gFp == NULL) {
		gFp = fopen("tst.yuv", "wb");
		if (gFp != NULL) {
			fwrite(i420_render_frame_->DataY(), 1, ww*hh, gFp);
			fwrite(i420_render_frame_->DataU(), 1, ww*hh/4, gFp);
			fwrite(i420_render_frame_->DataV(), 1, ww*hh/4, gFp);
		}
	}
#endif
};


