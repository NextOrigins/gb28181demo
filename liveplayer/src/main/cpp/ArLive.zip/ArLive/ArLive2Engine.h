/*
 *  Copyright (c) 2013 The WebRTC@AnyRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 *
 *  This is a part of the AR RTC Service SDK.
 *  Copyright (C) 2021 anRTC IO
 *  All rights reserved.
 *  Author - Eric.Mao
 *  Email - maozongwu@dync.cc
 *  Website - https://www.anyrtc.io
 *
 */
#ifndef __AR_LIVE2_ENGINE_H__
#define __AR_LIVE2_ENGINE_H__
#include "IArLive2Engine.h"
#include "AudDeviceEvent.h"
#include "RtcTick.h"
#include "MgrRender.h"
#include "PlatformImpl.h"
#include "rtc_base/deprecated/recursive_critical_section.h"
#include "rtc_base/thread.h"
#include "api/peer_connection_interface.h"
#include "api/video_codecs/video_encoder_factory.h"
#include "api/video_codecs/video_decoder_factory.h"
#include "modules/audio_coding/acm2/acm_resampler.h"
#include "modules/audio_device/include/audio_device.h"
#include "modules/audio_device/include/audio_device_defines.h"
#include "modules/video_capture/video_capture.h"

using namespace anyrtc;
class ArLive2Engine : public AR::IArLive2Engine, public rtc::Thread, public MThreadTick, webrtc::AudioTransport, public rtc::VideoSinkInterface<webrtc::VideoFrame>
{
public:
	ArLive2Engine(void);
	virtual ~ArLive2Engine(void);

	//* For IArLive2Engine
	virtual int32_t initialize(AR::IArLive2EngineObserver* observer);

	virtual void release();

#ifdef __ANDROID__
	virtual AR::IArLivePusher* createArLivePusher(void* context, AR::ArLiveMode mode);
	virtual AR::IArLivePlayer* createArLivePlayer(void* context, AR::uid_t playerId);
	virtual int startScreenCapture();
	virtual int stopScreenCapture();

#else
	virtual AR::IArLivePusher* createArLivePusher(AR::ArLiveMode mode);

	virtual AR::IArLivePlayer* createArLivePlayer(AR::uid_t playerId);
#endif
	virtual void releaseArLivePusher(AR::IArLivePusher* pusher);

	virtual void releaseArLivePlayer(AR::uid_t playerId, AR::IArLivePlayer* player);

public:
	virtual int32_t setupCameraRender(const AR::VideoCanvas& canvas);

	virtual int32_t setCameraRenderMirror(ArLiveMirrorType mirrorType);

	virtual int32_t setCameraRenderRotation(ArLiveRotation rotation);

	virtual int32_t setCameraDimensions(AR::VideoDimensions vidDimensions);

	virtual int32_t setPlayRenderView(AR::uid_t playerId, const AR::VideoCanvas& canvas);

	virtual int32_t setPlayRenderRotation(AR::uid_t playerId, ArLiveRotation rotation);

	virtual int32_t setPlayRenderFillMode(AR::uid_t playerId, ArLiveFillMode mode);

#if TARGET_PLATFORM_PHONE
	virtual int32_t startCamera(bool frontCamera);
	virtual int32_t switchCamera(bool frontCamera);
	virtual int32_t setBeautyEffect(bool enable);
#elif TARGET_PLATFORM_DESKTOP
	virtual int32_t startCamera(const char* cameraId);
#endif

	virtual int32_t stopCamera();

	virtual int32_t startMicrophone();

	virtual int32_t stopMicrophone();

#ifdef _WIN32
	virtual int32_t startVirtualCamera(ArLiveImage* image);
#endif

#ifdef _WIN32
	virtual int32_t stopVirtualCamera();
#endif

	virtual ITXDeviceManager* getDeviceManager();

	virtual int32_t enableCustomVideoCapture(bool enable);

	virtual int32_t sendCustomVideoFrame(ArLiveVideoFrame* videoFrame);

#ifdef _WIN32
	virtual int32_t enableCustomRendering(bool enable, ArLivePixelFormat pixelFormat, ArLiveBufferType bufferType);
#endif

#ifdef _WIN32
	virtual int enableCustomAudioCapture(bool enable);
#endif

#ifdef _WIN32
	virtual int sendCustomAudioFrame(ArLiveAudioFrame* audioFrame);
#endif

#if TARGET_PLATFORM_DESKTOP
	virtual int32_t startSystemAudioLoopback(const char* path = nullptr);

	virtual int32_t stopSystemAudioLoopback();

	virtual int32_t enableCustomVideoProcess(bool enable, ArLivePixelFormat pixelFormat, ArLiveBufferType bufferType);
#ifdef _WIN32
	virtual void startScreenCapture();

	virtual void stopScreenCapture();

	virtual IArLiveScreenCaptureSourceList* getScreenCaptureSources(const SIZE& thumbSize, const SIZE& iconSize);

	virtual void setScreenCaptureSource(const ArLiveScreenCaptureSourceInfo& source, const RECT& captureRect, const ArLiveScreenCaptureProperty& property);
#endif
#endif

	//* For rtc::Thread
	virtual void Run();

	//* For webrtc::AudioTransport
	virtual int32_t RecordedDataIsAvailable(const void* audioSamples, const size_t nSamples,
		const size_t nBytesPerSample, const size_t nChannels, const uint32_t samplesPerSec, const uint32_t totalDelayMS,
		const int32_t clockDrift, const uint32_t currentMicLevel, const bool keyPressed, uint32_t& newMicLevel);

	virtual int32_t NeedMorePlayData(const size_t nSamples, const size_t nBytesPerSample, const size_t nChannels,
		const uint32_t samplesPerSec, void* audioSamples, size_t& nSamplesOut, int64_t* elapsed_time_ms, int64_t* ntp_time_ms);

	// Method to pull mixed render audio data from all active VoE channels.
	// The data will not be passed as reference for audio processing internally.
	virtual void PullRenderData(int bits_per_sample,
		int sample_rate,
		size_t number_of_channels,
		size_t number_of_frames,
		void* audio_data,
		int64_t* elapsed_time_ms,
		int64_t* ntp_time_ms) {};

	// rtc::VideoSinkInterface<webrtc::VideoFrame>
	void OnFrame(const webrtc::VideoFrame& frame) override;

public:
	rtc::Thread* GetThread() {
		return this;
	}
	MgrRender& GetMgrRender() {
		return mgr_render_;
	}

	rtc::scoped_refptr<webrtc::PeerConnectionFactoryInterface> PeerConnectionFactory() {
		return peer_connection_factory_;
	}

	rtc::scoped_refptr<webrtc::VideoTrackSourceInterface> VideoSource() {
		return video_source_;
	}


protected:
	void InitAudDevice();
	void DeInitAudDevice();
	void InitPeerConnection();
	void DeInitPeerConnection();
public:
	void AttachAudCapture(AudDevCaptureEvent*pEvent);
	void DetachAudCapture(AudDevCaptureEvent*pEvent);

	void AttachAudSpeaker(AudDevSpeakerEvent*pEvent);
	void DetachAudSpeaker(AudDevSpeakerEvent*pEvent);


private:
	IArLive2EngineObserver* observer_;

	// Control or logic
	bool	b_running_;
	bool	b_aud_cap_exception_;
	bool	b_aud_ply_exception_;
	bool	b_video_preview_;
	bool	b_video_muted_;
	int64_t n_timer_100ms_;

private:
	MgrRender				mgr_render_;

	typedef std::map< AudDevCaptureEvent*, void*> MapAudDevCapture;
	typedef std::map< AudDevSpeakerEvent*, void*> MapAudDevSpeaker;
	rtc::RecursiveCriticalSection	cs_aud_capture_;
	MapAudDevCapture		map_aud_dev_capture_;
	rtc::RecursiveCriticalSection	cs_aud_speaker_;
	MapAudDevSpeaker		map_aud_dev_speaker_;

private:
	// Audio devices
	rtc::scoped_refptr<webrtc::AudioDeviceModule>		audio_device_ptr_;
	std::unique_ptr<webrtc::VideoEncoderFactory>		video_encoder_factory_;
	std::unique_ptr<webrtc::TaskQueueFactory>			task_queue_factory_;
	rtc::scoped_refptr<webrtc::AudioDeviceModule>		rtc_adm_;
	rtc::scoped_refptr<webrtc::PeerConnectionFactoryInterface> peer_connection_factory_;

private:
	// Video devices
	rtc::scoped_refptr<webrtc::VideoTrackSourceInterface> video_source_;
	struct PtVideoCap
	{
		PtVideoCap(const rtc::scoped_refptr<webrtc::VideoTrackSourceInterface>vidSource, size_t width, size_t height, size_t fps, size_t capture_device_index) : ptrCap(NULL), bStarted(false) {
			ptrCap = createPlatformVideoCapture(vidSource, width, height, fps, capture_device_index);
		}
		virtual ~PtVideoCap(void) {
			destoryPlatformVideoCapture(ptrCap);
			ptrCap = NULL;
		}
		void* ptrCap;
		bool bStarted;
#if (defined(WEBRTC_ANDROID))
		bool bIsScreen;
#endif
	};

	AR::VideoDimensions			video_dimensions_;
	std::unique_ptr<PtVideoCap> platform_video_cap_;

private:
	typedef std::map<std::string, IArLivePlayer*>MapArLive2Player;
	rtc::RecursiveCriticalSection	cs_arlive2_player_;
	MapArLive2Player		map_arlive2_player_;
};

#endif	// __AR_LIVE2_ENGINE_H__

