#ifndef __AR_LIVE2_PLAYER_H__
#define __AR_LIVE2_PLAYER_H__
#include "ArLive2Engine.h"
#include "IArLivePlayer.hpp"
#include "AudDeviceEvent.h"
#include <list>
#include "rtc_base/deprecated/recursive_critical_section.h"
#include "rtc_base/thread.h"
#include "api/video/i420_buffer.h"

#include "codec/pluginaac.h"
#include "PlayBuffer.h"
#include "ARPlayer.h"

class ArLive2Player : public AR::IArLivePlayer, public RtcTick, public PlayBuffer, public AudDevSpeakerEvent, public ARPlayerEvent
{
public:
	ArLive2Player(ArLive2Engine*pEngine, const char*playerId);
	virtual ~ArLive2Player(void);

	//* For AR::IArLivePlayer
	virtual void setObserver(AR::ArLivePlayerObserver* observer);
	virtual int32_t setRenderView(void* view);
	virtual int32_t setRenderRotation(ArLiveRotation rotation);
	virtual int32_t setRenderFillMode(ArLiveFillMode mode);
	virtual int32_t startPlay(const char* url);
	virtual int32_t stopPlay();
	virtual int32_t isPlaying();
	virtual int32_t pauseAudio();
	virtual int32_t resumeAudio();
	virtual int32_t pauseVideo();
	virtual int32_t resumeVideo();
	virtual int32_t setPlayoutVolume(int32_t volume);
	virtual int32_t setCacheParams(float minTime, float maxTime);
	virtual int32_t enableVolumeEvaluation(int32_t intervalMs);
	virtual int32_t snapshot();
	virtual int32_t enableCustomRendering(bool enable, AR::ArLivePixelFormat pixelFormat, AR::ArLiveBufferType bufferType);
	virtual int32_t enableReceiveSeiMessage(bool enable, int payloadType);
	virtual void showDebugView(bool isShow);

	//* For RtcTick
	virtual void OnTick();
	virtual void OnTickUnAttach();

	//* For PlayBuffer
	virtual void OnBufferVideoRender(VideoData *videoData, int64_t pts);
	virtual void OnFirstVideoDecoded();
	virtual void OnFirstAudioDecoded();

	//* For AudDevSpeakerEvent
	virtual int MixAudioData(bool mix, void* audioSamples, uint32_t samplesPerSec, int nChannels);

	//* For ARPlayerEvent
	virtual void OnArPlyOK(void*player);
	virtual void OnArPlyStatus(void*player, int cacheTime, int curBitrate);
	virtual void OnArPlyStart(void*player);
	virtual void OnArPlyCache(void*player, int time);
	virtual void OnArPlyClose(void*player, int errcode);

	virtual bool OnArPlyNeedMoreAudioData(void*player);
	virtual bool OnArPlyNeedMoreVideoData(void*player);
	virtual void OnArPlyAudio(void*player, const char*pData, int nSampleHz, int nChannels, int64_t pts);
	virtual void OnArPlyVideo(void*player, int fmt, int ww, int hh, uint8_t**pData, int*linesize, int64_t pts);

private:
	AR::ArLivePlayerObserver* observer_;

private:
	ArLive2Engine*			ar_engine_;
	rtc::Thread*			main_thread_;
	ARPlayer*				ar_player_;
	bool							b_play_ok_;
	bool							b_shutdown_;
	std::string						str_play_url_;

	AR::ArLivePlayConfig			ar_play_conf_;
	std::string						str_player_id_;

private:
	//* For audio
	uint8_t			*audio_cache_;
	int				a_cache_len_;
	uint32_t		aac_sample_hz_;
	uint8_t			aac_channels_;
	uint32_t		aac_frame_per10ms_size_;

private:
	rtc::RecursiveCriticalSection cs_render_frame_;
	rtc::scoped_refptr<webrtc::I420Buffer> i420_render_frame_;
};

#endif	// __AR_LIVE2_PLAYER_H__