#ifndef __AR_LIVE2_PUSHER_H__
#define __AR_LIVE2_PUSHER_H__
#include "ArLive2Engine.h"
#include "IArLivePusher.hpp"
#include "pusher/ARPusher.h"
#include "codec/AvCodec.h"
#include "api/media_stream_interface.h"

class ArLive2Pusher : public AR::IArLivePusher, public RtcTick, public AudDevCaptureEvent, public rtc::VideoSinkInterface<webrtc::VideoFrame>, public AR::ArLivePusherObserver, public webrtc::AVCodecCallback
{
public:
	ArLive2Pusher(ArLive2Engine*pEngine);
	virtual ~ArLive2Pusher(void);

	void setVideoSource(const rtc::scoped_refptr<webrtc::VideoTrackSourceInterface>vidSource);
	void setExVideoEncoderFactory(webrtc::VideoEncoderFactory *video_encoder_factory);

	//* For IArLivePushKit
	virtual void setObserver(ArLivePusherObserver* observer);
	virtual int32_t setEncoderMirror(bool mirror);
	virtual int32_t pauseAudio();
	virtual int32_t resumeAudio();
	virtual int32_t pauseVideo();
	virtual int32_t resumeVideo();
	virtual int32_t startPush(const char* url);
	virtual int32_t stopPush();
	virtual int32_t isPushing();
	virtual int32_t setAudioQuality(ArLiveAudioQuality quality);
	virtual int32_t setVideoQuality(const ArLiveVideoEncoderParam& param);
	virtual ITXAudioEffectManager* getAudioEffectManager();
	virtual int32_t snapshot();
	virtual int32_t setWatermark(const char* watermarkPath, float x, float y, float scale);
	virtual int32_t enableVolumeEvaluation(int32_t intervalMs);
	virtual int32_t sendSeiMessage(int payloadType, const uint8_t* data, uint32_t dataSize);
	virtual void showDebugView(bool isShow);

	//* For RtcTick
	virtual void OnTick();
	virtual void OnTickUnAttach();

	//* For ArLivePushSinkInterface
	void initAudioWithParameters(int nType, int sampleRate, int numChannels, int audBitrate);
	void deinitAudio();
	void initVideoWithParameters(int nType, int videoWidth, int videoHeight, int videoFps, int videoBitrate);
	void deinitVideo();

	//* For AudDevCaptureEvent
	virtual void RecordedDataIsAvailable(const void* audioSamples, const size_t nSamples,
		const size_t nBytesPerSample, const size_t nChannels, const uint32_t samplesPerSec, const uint32_t totalDelayMS);

	// rtc::VideoSinkInterface<webrtc::VideoFrame>
	void OnFrame(const webrtc::VideoFrame& frame) override;

	//* For AR::ArLivePusherObserver
	virtual void onError(int32_t code, const char* msg, void* extraInfo);
	virtual void onWarning(int32_t code, const char* msg, void* extraInfo);
	virtual void onPushStatusUpdate(ArLivePushStatus state, const char* msg, void* extraInfo);
	virtual void onStatisticsUpdate(ArLivePusherStatistics statistics);

	//* For AVCodecCallback
	virtual void OnEncodeDataCallback(bool audio, bool bKeyFrame, const uint8_t *pData, uint32_t length, uint32_t ts);

private:
	ArLive2Engine*					ar_engine_;
	rtc::Thread* main_thread_;

	AR::ArLivePusherObserver*		event_live_push_;

	// Video devices
	rtc::scoped_refptr<webrtc::VideoTrackSourceInterface> video_source_;

private:
	bool						b_live_pushed_;
	bool						b_push_paused_;
	bool						b_auto_republish_;
	std::string					str_rtmp_url_;
	ARPusher*					ar_pusher_;

private:
	webrtc::A_AACEncoder*		aac_encoder_;
	webrtc::V_H264Encoder*		h264_encoder_;
	webrtc::VideoEncoderFactory  *exVideo_encoder_factory;
};


#endif	// __AR_LIVE2_PUSHER_H__