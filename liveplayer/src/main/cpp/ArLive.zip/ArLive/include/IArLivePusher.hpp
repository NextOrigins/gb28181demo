﻿/// @defgroup ArLivePusher_cplusplus ArLivePusher
/// anyRTC开源直播推流器。<br/>
/// 主要负责将本地的音频和视频画面进行编码，并推送到指定的推流地址，支持任意的推流服务端。
///
/// 推流器包含如下能力：
/// - 自定义的视频采集，让您可以根据项目需要定制自己的音视频数据源；
/// - Qos 流量控制技术，具备上行网络自适应能力，可以根据主播端网络的具体情况实时调节音视频数据量；
/// - 脸形调整、动效挂件，支持基于优图 AI 人脸识别技术的大眼、瘦脸、隆鼻等脸形微调以及动效挂件效果，只需要购买 **优图 License** 就可以轻松实现丰富的直播效果。
///
/// @{

#ifndef MODULE_CPP_I_ARLIVEPUSHER_H_
#define MODULE_CPP_I_ARLIVEPUSHER_H_

#include "ArLiveDef.hpp"
#include "ArLivePusherObserver.hpp"
#include "IArAudioEffectManager.h"
#include "IArDeviceManager.h"

namespace anyrtc {
class IArLivePusher;
}

namespace anyrtc {

class IArLivePusher {
   public:
    /**
     * 设置推流器回调。
     *
     * 通过设置回调，可以监听 ArLivePusher 推流器的一些回调事件，
     * 包括推流器状态、音量回调、统计数据、警告和错误信息等。
     *
     * @param observer 推流器的回调目标对象，更多信息请查看 {@link ArLivePusherObserver}
     */
    virtual void setObserver(ArLivePusherObserver* observer) = 0;

    /**
     * 设置视频编码镜像。
     *
     * @note  编码镜像只影响观众端看到的视频效果。
     * @param mirror 是否镜像
     *         - false【默认值】: 播放端看到的是非镜像画面
     *         - true: 播放端看到的是镜像画面
     * @return 返回值 {@link ArLiveCode}
     *         - ArLIVE_OK: 成功
     */
    virtual int32_t setEncoderMirror(bool mirror) = 0;


    /**
     * 暂停推流器的音频流。
     *
     * @return 返回值 {@link ArLiveCode}
     *         - ArLIVE_OK: 成功
     */
    virtual int32_t pauseAudio() = 0;

    /**
     * 恢复推流器的音频流。
     *
     * @return 返回值 {@link ArLiveCode}
     *         - ArLIVE_OK: 成功
     */
    virtual int32_t resumeAudio() = 0;

    /**
     * 暂停推流器的视频流。
     *
     * @return 返回值 {@link ArLiveCode}
     *         - ArLIVE_OK: 成功
     */
    virtual int32_t pauseVideo() = 0;

    /**
     * 恢复推流器的视频流。
     *
     * @return 返回值 {@link ArLiveCode}
     *         - ArLIVE_OK: 成功
     */
    virtual int32_t resumeVideo() = 0;

    /**
     * 开始音视频数据推流。
     *
     * @param url 推流的目标地址，支持任意推流服务端
     * @return 返回值 {@link ArLiveCode}
     *         - ArLIVE_OK: 操作成功，开始连接推流目标地址
     *         - ArLIVE_ERROR_INVALID_PARAMETER: 操作失败，url 不合法
     *         - ArLIVE_ERROR_INVALID_LICENSE: 操作失败，license 不合法，鉴权失败
     *         - ArLIVE_ERROR_REFUSED: 操作失败，RTC 不支持同一设备上同时推拉同一个 StreamId
     */
    virtual int32_t startPush(const char* url) = 0;

    /**
     * 停止推送音视频数据。
     *
     * @return 返回值 {@link ArLiveCode}
     *         - ArLIVE_OK: 成功
     */
    virtual int32_t stopPush() = 0;

    /**
     * 当前推流器是否正在推流中。
     *
     * @return 是否正在推流
     *         - 1: 正在推流中
     *         - 0: 已经停止推流
     */
    virtual int32_t isPushing() = 0;

    /**
     * 设置推流音频质量。
     *
     * @param quality 音频质量 {@link ArLiveAudioQuality}
     *         - ArLiveAudioQualityDefault 【默认值】: 通用
     *         - ArLiveAudioQualitySpeech: 语音
     *         - ArLiveAudioQualityMusic:  音乐
     * @return 返回值 {@link ArLiveCode}
     *         - ArLIVE_OK: 成功
     *         - ArLIVE_ERROR_REFUSED: 推流过程中，不允许调整音质
     */
    virtual int32_t setAudioQuality(ArLiveAudioQuality quality) = 0;

    /**
     * 设置推流视频编码参数
     *
     * @param param  视频编码参数 {@link ArLiveVideoEncoderParam}
     * @return 返回值 {@link ArLiveCode}
     *         - ArLIVE_OK: 成功
     */
    virtual int32_t setVideoQuality(const ArLiveVideoEncoderParam& param) = 0;

    /**
     * 获取音效管理对象 {@link TXAudioEffectManager}。
     *
     * 通过音效管理，您可以使用以下功能：
     * - 调整麦克风收集的人声音量。
     * - 设置混响和变声效果。
     * - 开启耳返，设置耳返音量。
     * - 添加背景音乐，调整背景音乐的播放效果。
     */
    virtual ITXAudioEffectManager* getAudioEffectManager() = 0;

    /**
     * 截取推流过程中的本地画面。
     *
     * @return 返回值 {@link ArLiveCode}
     *         - ArLIVE_OK: 成功
     *         - ArLIVE_ERROR_REFUSED: 已经停止推流，不允许调用截图操作
     */
    virtual int32_t snapshot() = 0;

    /**
     * 设置推流器水印。默认情况下，水印不开启。
     *
     * 水印的位置是通过 x, y, scale 来指定的。
     * - x：水印的坐标，取值范围为0 - 1的浮点数。
     * - y：水印的坐标，取值范围为0 - 1的浮点数。
     * - scale：水印的大小比例，取值范围为0 - 1的浮点数。
     *
     * @param watermarkPath 水印图片文件路径，为 nullptr 则等同于关闭水印
     * @param x             水印显示的左上角 x 轴偏移
     * @param y             水印显示的左上角 y 轴偏移
     * @param scale         水印显示的宽度占画面宽度比例（水印按该参数等比例缩放显示）
     *
     * @return 返回值 {@link ArLiveCode}
     *         - ArLIVE_OK: 成功
     *
     * @note watermarkPath
     * 1、在 iOS/Mac 坏境下，如果图片存放在 .xcassets 中，请直接传入文件名：
     * self.pusher->setWatermark(“imageName”, 0.1, 0.1, 0.2);
     * 2、在 Android 坏境，如果图片存放在 assets 目录下，请直接传入文件名或者路径名：
     * self.pusher->setWatermark(“imageName.png”, 0.1, 0.1, 0.2);
     * 其它没有列举到的情况，按照各平台的方式获取文件路径并传入即可。
     */
    virtual int32_t setWatermark(const char* watermarkPath, float x, float y, float scale) = 0;

    /**
     * 启用采集音量大小提示。
     *
     * 开启后可以在 {@link ArLivePusherObserver#onMicrophoneVolumeUpdate(int)} 回调中获取到 SDK 对音量大小值的评估。
     * @param intervalMs 决定了 onMicrophoneVolumeUpdate 回调的触发间隔，单位为ms，最小间隔为100ms，如果小于等于0则会关闭回调，建议设置为300ms；【默认值】：0，不开启
     * @return 返回值 {@link ArLiveCode}
     *         - ArLIVE_OK: 成功
     */
    virtual int32_t enableVolumeEvaluation(int32_t intervalMs) = 0;

    /**
     * 发送 SEI 消息
     *
     * 播放端 {@link ArLivePlayer} 通过 {@link ArLivePlayerObserver} 中的 `onReceiveSeiMessage` 回调来接收该消息。
     *
     * @param payloadType 数据类型，支持 5、242。推荐填：242
     * @param data        待发送的数据
     * @param dataSize    数据大小
     * @return 返回值 {@link ArLiveCode}
     *         - ArLIVE_OK: 成功
     */
    virtual int32_t sendSeiMessage(int payloadType, const uint8_t* data, uint32_t dataSize) = 0;

    /**
     * 显示仪表盘。
     *
     * @param isShow 是否显示。【默认值】：false
     */
    virtual void showDebugView(bool isShow) = 0;

   protected:
    virtual ~IArLivePusher(){};
};

}  // namespace anyrtc

#endif  // MODULE_CPP_I_ARLIVEPUSHER_H_
/// @}
