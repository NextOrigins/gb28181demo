﻿/// @defgroup ArLivePusherObserver_cplusplus ArLivePusherObserver
/// anyRTC开源直播推流的回调通知。<br/>
/// ArLivePusher 的一些回调事件，包括推流器状态，推流音量，统计信息，警告以及错误信息。
/// @{

#ifndef MODULE_CPP_ARLIVEPUSHEROBSERVER_H_
#define MODULE_CPP_ARLIVEPUSHEROBSERVER_H_

#include "ArLiveDef.hpp"

namespace anyrtc {

class ArLivePusherObserver {
   public:
    virtual ~ArLivePusherObserver(){};

    /**
     * 直播推流器错误通知，推流器出现错误时，会回调该通知
     *
     * @param code      错误码 {@link ArLiveCode}
     * @param msg       错误信息
     * @param extraInfo 扩展信息
     */
    virtual void onError(int32_t code, const char* msg, void* extraInfo){};

    /**
     * 直播推流器警告通知
     *
     * @param code      警告码 {@link ArLiveCode}
     * @param msg       警告信息
     * @param extraInfo 扩展信息
     */
    virtual void onWarning(int32_t code, const char* msg, void* extraInfo){};

    /**
     * 推流器连接状态回调通知
     *
     * @param status    推流器连接状态 {@link ArLivePushStatus}
     * @param msg       连接状态信息
     * @param extraInfo 扩展信息
     */
    virtual void onPushStatusUpdate(ArLivePushStatus state, const char* msg, void* extraInfo){};

    /**
     * 直播推流器统计数据回调
     *
     * @param statistics 推流器统计数据 {@link ArLivePusherStatistics}
     */
    virtual void onStatisticsUpdate(ArLivePusherStatistics statistics){};

    /**
     * 截图回调
     *
     * @note  调用 [snapshot](@ref ArLivePusher#snapshot) 截图之后，会收到这个回调通知
     *
     * @param image  已截取的视频画面
     * @param length 截图数据长度，对于BGRA32而言，length = width * height * 4
     * @param width  截图画面的宽度
     * @param height 截图画面的高度
     * @param format 截图数据格式，目前只支持 ArLivePixelFormatBGRA32
     */
    virtual void onSnapshotComplete(const char* image, int length, int width, int height, ArLivePixelFormat format){};
};
}  // namespace anyrtc
#endif  // MODULE_CPP_ARLIVEPUSHEROBSERVER_H_
/// @}
