#ifndef __I_RTC_PLAYER_H__
#define __I_RTC_PLAYER_H__
#include "ARPlayer.h"


ARP_API ARPlayer* ARP_CALL createRtcPlayer(ARPlayerEvent&callback);

#endif	// __I_RTC_PLAYER_H__
