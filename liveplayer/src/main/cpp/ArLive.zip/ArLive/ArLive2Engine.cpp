#ifdef __ANDROID__
#include <PlatformInterface.h>
#endif
#include "ArLive2Engine.h"
#include "ArLive2Player.h"
#include "ArLive2Pusher.h"
#include "rtc_base/bind.h"
#include "api/task_queue/default_task_queue_factory.h"
#include "modules/audio_device/include/audio_device.h"
#include "rtc_base/internal/default_socket_server.h"
#include "rtc_base/task_queue_gcd.h"
#include "modules/video_capture/video_capture_impl.h"
#include "modules/audio_device/dummy/audio_device_dummy.h"
#include "api/audio_codecs/audio_decoder_factory.h"
#include "api/audio_codecs/audio_encoder_factory.h"
#include "api/audio_codecs/builtin_audio_decoder_factory.h"
#include "api/audio_codecs/builtin_audio_encoder_factory.h"
#include "api/audio_options.h"
#include "api/create_peerconnection_factory.h"
#include "api/video_codecs/builtin_video_decoder_factory.h"
#include "api/video_codecs/builtin_video_encoder_factory.h"
#include "api/video_codecs/video_decoder_factory.h"
#include "api/video_codecs/video_encoder_factory.h"

#define LOCAL_CAP_ID	"LocalCap"
// RtcEngine �ǵ���ֻ�ܴ���һ��
static ArLive2Engine* gInstance = NULL;

AR::IArLive2Engine* V2_CALL AR::createArLive2Engine()
{
	if (gInstance == NULL) {
		gInstance = new ArLive2Engine();
	}
	return gInstance;
}
ArLive2Engine::ArLive2Engine(void)
	: rtc::Thread(rtc::CreateDefaultSocketServer())
	, observer_(NULL)
	, b_running_(false)
	, b_aud_cap_exception_(false)
	, b_aud_ply_exception_(false)
	, b_video_preview_(false)
	, b_video_muted_(false)
	, n_timer_100ms_(0)
{
}
ArLive2Engine::~ArLive2Engine(void)
{
	//* ��������ʱ����յ�������
	gInstance = NULL;
}

//* For IArLive2Engine
int32_t ArLive2Engine::initialize(AR::IArLive2EngineObserver* observer)
{
	if (!b_running_) {
		b_running_ = true;
		observer_ = observer;
		rtc::Thread::Start();

		rtc::Thread::Invoke<void>(RTC_FROM_HERE, rtc::Bind(&ArLive2Engine::InitAudDevice, this));

		rtc::Thread::Invoke<void>(RTC_FROM_HERE, rtc::Bind(&ArLive2Engine::InitPeerConnection, this));

		video_source_ = createPlatformVideoSouce();

		rtc::VideoSinkWants wants;
		video_source_->AddOrUpdateSink(this, wants);
	}
	else {
		return ArLIVE_ERROR_FAILED;
	}
	return ArLIVE_OK;
}

void ArLive2Engine::release()
{
	if (b_running_) {
		rtc::Thread::Invoke<void>(RTC_FROM_HERE, rtc::Bind(&ArLive2Engine::DeInitPeerConnection, this));

		rtc::Thread::Invoke<void>(RTC_FROM_HERE, rtc::Bind(&ArLive2Engine::DeInitAudDevice, this));

		b_running_ = false;
		rtc::Thread::Stop();

		if (video_source_ != NULL) {
			video_source_->RemoveSink(this);
		}
		video_source_ = nullptr;
	}

	delete this;
}

#ifdef __ANDROID__
AR::IArLivePusher* ArLive2Engine::createArLivePusher(void* context, AR::ArLiveMode mode)
{
	ArLive2Pusher* pusher = new ArLive2Pusher(this);
	pusher->setVideoSource(video_source_);
	std::unique_ptr<webrtc::VideoEncoderFactory> video_encoder_factory = arlive::PlatformInterface::SharedInstance()->makeVideoEncoderFactory(platformContext);
	pusher->setExVideoEncoderFactory(video_encoder_factory.release());
	return pusher;
}

AR::IArLivePlayer* ArLive2Engine::createArLivePlayer(void* context, AR::uid_t playerId)
{
	rtc::CritScope l(&cs_arlive2_player_);
	if (map_arlive2_player_.find(playerId) == map_arlive2_player_.end()) {
		AR::IArLivePlayer* arLivePlayer = new ArLive2Player(this, playerId);
		map_arlive2_player_[playerId] = arLivePlayer;
		return arLivePlayer;
	}
	else {
		// java ����ʵ��
	}
	return NULL;
}

int ArLive2Engine::startScreenCapture()
{

	if (platform_video_cap_ == NULL) {
		platform_video_cap_.reset(new PtVideoCap(video_source_, video_dimensions_.width, video_dimensions_.height, 25, 8));
		platform_video_cap_->bIsScreen = true;
	}

	if (!platform_video_cap_->bStarted) {
		platform_video_cap_->bStarted = startPlatformVideoCapture(platform_video_cap_->ptrCap);
	}

	return 0;
}

int ArLive2Engine::stopScreenCapture()
{

	if (platform_video_cap_ != NULL) {
		if (platform_video_cap_->bStarted) {
			platform_video_cap_->bStarted = false;
			stopPlatformVideoCapture(platform_video_cap_->ptrCap);
		}
	}
	platform_video_cap_ = nullptr;

	return 0;
}
#else
AR::IArLivePusher* ArLive2Engine::createArLivePusher(AR::ArLiveMode mode)
{
	return new ArLive2Pusher(this);
}

AR::IArLivePlayer* ArLive2Engine::createArLivePlayer(AR::uid_t playerId)
{
	rtc::CritScope l(&cs_arlive2_player_);
	if (map_arlive2_player_.find(playerId) == map_arlive2_player_.end()) {
		AR::IArLivePlayer* arLivePlayer = new ArLive2Player(this, playerId);
		map_arlive2_player_[playerId] = arLivePlayer;
		return arLivePlayer;
	}
	else {

	}
	return NULL;
}
#endif
void ArLive2Engine::releaseArLivePusher(AR::IArLivePusher* pusher)
{
	if (pusher != NULL) {
		delete (ArLive2Pusher*)pusher;
		pusher = NULL;
	}
}

void ArLive2Engine::releaseArLivePlayer(AR::uid_t playerId, AR::IArLivePlayer* player)
{
	rtc::CritScope l(&cs_arlive2_player_);
	if (map_arlive2_player_.find(playerId) != map_arlive2_player_.end()) {
		AR::IArLivePlayer* arLivePlayer = map_arlive2_player_[playerId];
		map_arlive2_player_.erase(playerId);
		delete (ArLive2Player*)arLivePlayer;
		arLivePlayer = NULL;
	}
}

int32_t ArLive2Engine::setupCameraRender(const AR::VideoCanvas& canvas)
{
	mgr_render_.SetRender(LOCAL_CAP_ID, NULL);

	if (canvas.view != NULL) {
		webrtc::VideoRenderer *render = webrtc::VideoRenderer::CreatePlatformRenderer(canvas.view, 640, 480);
		mgr_render_.SetRender(LOCAL_CAP_ID, render);
	}
	return 0;
}

int32_t ArLive2Engine::setCameraRenderMirror(ArLiveMirrorType mirrorType)
{
	return 0;
}

int32_t ArLive2Engine::setCameraRenderRotation(ArLiveRotation rotation){ return 0; }

int32_t ArLive2Engine::setCameraDimensions(AR::VideoDimensions vidDimensions)
{
	video_dimensions_ = vidDimensions;
	return ArLIVE_OK;
}

int32_t ArLive2Engine::setPlayRenderView(AR::uid_t playerId, const AR::VideoCanvas& canvas)
{
	if (playerId != NULL) {
		mgr_render_.SetRender(playerId, NULL);
		if (canvas.view != NULL) {
			webrtc::VideoRenderer *render = webrtc::VideoRenderer::CreatePlatformRenderer(canvas.view, 640, 480);
			mgr_render_.SetRender(playerId, render);
		}
	}
	return 0; 
}

int32_t ArLive2Engine::setPlayRenderRotation(AR::uid_t playerId, ArLiveRotation rotation){ return 0; }

int32_t ArLive2Engine::setPlayRenderFillMode(AR::uid_t playerId, ArLiveFillMode mode){ return 0; }

#if TARGET_PLATFORM_PHONE
int32_t ArLive2Engine::startCamera(bool frontCamera)
{
#if (defined(WEBRTC_ANDROID))
	if (platform_video_cap_ == NULL) {
		platform_video_cap_.reset(new PtVideoCap(video_source_, video_dimensions_.width, video_dimensions_.height, 25, frontCamera? 0 : 1));
		platform_video_cap_->bIsScreen = false;
	}
	if (!platform_video_cap_->bStarted) {
		platform_video_cap_->bStarted = startPlatformVideoCapture(platform_video_cap_->ptrCap);
	}
#endif
	return 0;
}
int32_t ArLive2Engine::switchCamera(bool frontCamera){
	if (platform_video_cap_ != NULL && !platform_video_cap_->bIsScreen) {
		switchPlatformVideoCapture(platform_video_cap_->ptrCap,frontCamera);
		return 0;
	}
	return -1;
}

int32_t ArLive2Engine::setBeautyEffect(bool enable){
	if (platform_video_cap_ != NULL && !platform_video_cap_->bIsScreen) {
		platformVideoCaptureSetBeautyEffect(platform_video_cap_->ptrCap,enable);
		return 0;
	}
	return -1;
}


#elif TARGET_PLATFORM_DESKTOP
int32_t ArLive2Engine::startCamera(const char* cameraId)
{
	int nDevIdx = 0;
	if (cameraId != NULL && strlen(cameraId) > 0) {

	}
	if (platform_video_cap_ == NULL) {
		platform_video_cap_.reset(new PtVideoCap(video_source_, video_dimensions_.width, video_dimensions_.height, video_dimensions_.fps, nDevIdx));
	}

	if (!platform_video_cap_->bStarted) {
		platform_video_cap_->bStarted = startPlatformVideoCapture(platform_video_cap_->ptrCap);
	}

	return 0;
}
#endif

int32_t ArLive2Engine::stopCamera()
{
	if (!rtc::Thread::IsCurrent()) {
		return rtc::Thread::Invoke<int>(RTC_FROM_HERE, rtc::Bind(&ArLive2Engine::stopCamera, this));
	}
	if (platform_video_cap_ != NULL) {
		if (platform_video_cap_->bStarted) {
			platform_video_cap_->bStarted = false;
			stopPlatformVideoCapture(platform_video_cap_->ptrCap);
		}
	}
	platform_video_cap_ = nullptr;

	return 0;
}

int32_t ArLive2Engine::startMicrophone()
{
	if (!rtc::Thread::IsCurrent()) {
		return rtc::Thread::Invoke<int>(RTC_FROM_HERE, rtc::Bind(&ArLive2Engine::startMicrophone, this));
	}
	if (!audio_device_ptr_->Recording()) {
		audio_device_ptr_->InitRecording();
		if (audio_device_ptr_->StartRecording() != 0) {
			audio_device_ptr_->StopRecording();
			b_aud_cap_exception_ = true;
		}
		else {
			b_aud_cap_exception_ = false;
		}
	}
	return ArLIVE_OK;
}

int32_t ArLive2Engine::stopMicrophone()
{
	if (!rtc::Thread::IsCurrent()) {
		return rtc::Thread::Invoke<int>(RTC_FROM_HERE, rtc::Bind(&ArLive2Engine::stopMicrophone, this));
	}
	if (audio_device_ptr_->Recording()) {
		audio_device_ptr_->StopRecording();
	}
	return ArLIVE_OK;
}

#ifdef _WIN32
int32_t ArLive2Engine::startVirtualCamera(ArLiveImage* image){ return 0; }
#endif

#ifdef _WIN32
int32_t ArLive2Engine::stopVirtualCamera(){ return 0; }
#endif

ITXDeviceManager* ArLive2Engine::getDeviceManager(){ return 0; }

int32_t ArLive2Engine::enableCustomVideoCapture(bool enable){ return 0; }

int32_t ArLive2Engine::sendCustomVideoFrame(ArLiveVideoFrame* videoFrame){ return 0; }

#ifdef _WIN32
int32_t ArLive2Engine::enableCustomRendering(bool enable, ArLivePixelFormat pixelFormat, ArLiveBufferType bufferType){ return 0; }
#endif

#ifdef _WIN32
int ArLive2Engine::enableCustomAudioCapture(bool enable){ return 0; }
#endif

#ifdef _WIN32
int ArLive2Engine::sendCustomAudioFrame(ArLiveAudioFrame* audioFrame){ return 0; }
#endif

#if TARGET_PLATFORM_DESKTOP

int32_t ArLive2Engine::startSystemAudioLoopback(const char* path){ return 0; }

int32_t ArLive2Engine::stopSystemAudioLoopback(){ return 0; }

int32_t ArLive2Engine::enableCustomVideoProcess(bool enable, ArLivePixelFormat pixelFormat, ArLiveBufferType bufferType){ return 0; }

#ifdef _WIN32
void ArLive2Engine::startScreenCapture(){}

void ArLive2Engine::stopScreenCapture(){}

IArLiveScreenCaptureSourceList* ArLive2Engine::getScreenCaptureSources(const SIZE& thumbSize, const SIZE& iconSize) { return NULL; }

void ArLive2Engine::setScreenCaptureSource(const ArLiveScreenCaptureSourceInfo& source, const RECT& captureRect, const ArLiveScreenCaptureProperty& property){}
#endif

#endif

//* For rtc::Thread
void ArLive2Engine::Run()
{
	while (b_running_)
	{
		MThreadTick::DoProcess();

		if (n_timer_100ms_ <= rtc::TimeUTCMillis()) {
			n_timer_100ms_ = rtc::TimeUTCMillis() + 100;

			if (b_aud_cap_exception_) {// ��Ƶ�ɼ��豸���쳣���ٴγ��Դ�
				audio_device_ptr_->InitRecording();
				if (audio_device_ptr_->StartRecording() != 0) {
					audio_device_ptr_->StopRecording();
					b_aud_cap_exception_ = true;
				}
				else {
					b_aud_cap_exception_ = false;
				}
			}

			if (b_aud_ply_exception_) {// ��Ƶ�����豸���쳣���ٴγ��Դ�
				audio_device_ptr_->InitPlayout();
				if (audio_device_ptr_->StartPlayout() != 0) {
					audio_device_ptr_->StopPlayout();
					b_aud_ply_exception_ = true;
				}
				else {
					b_aud_ply_exception_ = false;
				}
			}
		}


		rtc::Thread::SleepMs(1);
		rtc::Thread::ProcessMessages(1);
#ifdef WIN32
		w32_thread.ProcessMessages(1);
#endif
	}
}

//* For webrtc::AudioTransport
int32_t ArLive2Engine::RecordedDataIsAvailable(const void* audioSamples, const size_t nSamples,
	const size_t nBytesPerSample, const size_t nChannels, const uint32_t samplesPerSec, const uint32_t totalDelayMS,
	const int32_t clockDrift, const uint32_t currentMicLevel, const bool keyPressed, uint32_t& newMicLevel)
{
	rtc::CritScope l(&cs_aud_capture_);
	MapAudDevCapture::iterator itadr = map_aud_dev_capture_.begin();
	while (itadr != map_aud_dev_capture_.end()) {
		itadr->first->RecordedDataIsAvailable(audioSamples, nSamples, nBytesPerSample, nChannels, samplesPerSec, totalDelayMS);
		itadr++;
	}

	if (rtc_adm_ != NULL)
	{
		webrtc::AudioSinkInterface::Data audData((int16_t*)audioSamples, nSamples, samplesPerSec, nChannels, rtc::Time32());
		((webrtc::AudioDeviceDummy*)rtc_adm_->DummyDevice())->SetRecordAudioData(audData);
	}
	return 0;
}

int32_t ArLive2Engine::NeedMorePlayData(const size_t nSamples, const size_t nBytesPerSample, const size_t nChannels,
	const uint32_t samplesPerSec, void* audioSamples, size_t& nSamplesOut, int64_t* elapsed_time_ms, int64_t* ntp_time_ms)
{
	bool bMix = false;
	memset(audioSamples, 0, nSamples* nBytesPerSample);
	{
		rtc::CritScope l(&cs_aud_speaker_);
		MapAudDevSpeaker::iterator iter = map_aud_dev_speaker_.begin();
		while (iter != map_aud_dev_speaker_.end()) {
			if (iter->first->MixAudioData(bMix, audioSamples, samplesPerSec, nChannels) > 0) {
				bMix = true;
			}
			iter++;
		}
	}

	int samples_per_channel_int = samplesPerSec / 100;
	nSamplesOut = samples_per_channel_int * nChannels;

	if (rtc_adm_ != NULL)
	{
		char pData[1920];
		uint32_t nSampleHz = 48000;
		size_t nChannel = 1;
		{
			((webrtc::AudioDeviceDummy*)rtc_adm_->DummyDevice())->GetNeedPlayAudio(pData, nSampleHz, nChannel);
		}
	}
	return 0;
}

// rtc::VideoSinkInterface<webrtc::VideoFrame>
void ArLive2Engine::OnFrame(const webrtc::VideoFrame& frame)
{
	GetMgrRender().DoRenderFrame(LOCAL_CAP_ID, frame);
}


void ArLive2Engine::InitAudDevice()
{
	RTC_CHECK(audio_device_ptr_ == NULL);
	if (task_queue_factory_ == NULL) {
#if defined(WEBRTC_IOS) | defined(WEBRTC_MAC)
		task_queue_factory_ = webrtc::CreateTaskQueueGcdFactory();
#else
		task_queue_factory_ = webrtc::CreateDefaultTaskQueueFactory();
#endif
	}
	audio_device_ptr_ = webrtc::AudioDeviceModule::Create(webrtc::AudioDeviceModule::kPlatformDefaultAudio, task_queue_factory_.get());
	audio_device_ptr_->Init();
	audio_device_ptr_->AddRef();
	if (audio_device_ptr_->BuiltInAECIsAvailable())
		audio_device_ptr_->EnableBuiltInAEC(false);
	if (audio_device_ptr_->BuiltInAGCIsAvailable())
		audio_device_ptr_->EnableBuiltInAGC(false);
	if (audio_device_ptr_->BuiltInNSIsAvailable())
		audio_device_ptr_->EnableBuiltInNS(false);
	audio_device_ptr_->RegisterAudioCallback(this);
	// Initialize the default microphone
#ifdef WIN32
	if (audio_device_ptr_->SetRecordingDevice(
		webrtc::AudioDeviceModule::kDefaultCommunicationDevice) != 0) {
		audio_device_ptr_->InitMicrophone();
	}
#endif

#ifdef WIN32
	if (audio_device_ptr_->SetPlayoutDevice(webrtc::AudioDeviceModule::kDefaultCommunicationDevice) == 0) {
		audio_device_ptr_->InitSpeaker();
		audio_device_ptr_->SetStereoPlayout(true);
	}
#endif
}
void ArLive2Engine::DeInitAudDevice()
{
	RTC_CHECK(audio_device_ptr_ != NULL);
	if (audio_device_ptr_->Recording())
		audio_device_ptr_->StopRecording();
	if (audio_device_ptr_->Playing())
		audio_device_ptr_->StopPlayout();
	audio_device_ptr_->RegisterAudioCallback(NULL);
	audio_device_ptr_->Release();
	audio_device_ptr_ = NULL;
}
void ArLive2Engine::InitPeerConnection()
{
	if (task_queue_factory_ == NULL) {
#if defined(WEBRTC_IOS) | defined(WEBRTC_MAC)
		task_queue_factory_ = webrtc::CreateTaskQueueGcdFactory();
#else
		task_queue_factory_ = webrtc::CreateDefaultTaskQueueFactory();
#endif
}
	rtc_adm_ = webrtc::AudioDeviceModule::Create(webrtc::AudioDeviceModule::kDummyAudio, task_queue_factory_.get());
	rtc_adm_->Init();

	peer_connection_factory_ = webrtc::CreatePeerConnectionFactory(
		nullptr /* network_thread */, this /* worker_thread */,
		nullptr /* signaling_thread */, rtc_adm_ /* default_adm */,
		webrtc::CreateBuiltinAudioEncoderFactory(),
		webrtc::CreateBuiltinAudioDecoderFactory(),
		webrtc::CreateBuiltinVideoEncoderFactory(),
		webrtc::CreateBuiltinVideoDecoderFactory(), nullptr /* audio_mixer */,
		nullptr /* audio_processing */);

	//* ������peer_connection_factory_֮�󣬷���audioBuffer�����audioTransport��ע��ʧ��
	rtc_adm_->InitPlayout();
	rtc_adm_->InitRecording();
	rtc_adm_->StartPlayout();
	rtc_adm_->StartRecording();
}
void ArLive2Engine::DeInitPeerConnection()
{
	peer_connection_factory_ = nullptr;
	rtc_adm_->Terminate();
	rtc_adm_ = nullptr;
}
void ArLive2Engine::AttachAudCapture(AudDevCaptureEvent*pEvent)
{
	if (!rtc::Thread::IsCurrent()) {
		rtc::Thread::Invoke<void>(RTC_FROM_HERE, rtc::Bind(&ArLive2Engine::AttachAudCapture, this, pEvent));
		return;
	}
	RTC_CHECK(rtc::Thread::IsCurrent());
	rtc::CritScope l(&cs_aud_capture_);
	if (map_aud_dev_capture_.find(pEvent) == map_aud_dev_capture_.end()) {
		map_aud_dev_capture_[pEvent] = pEvent;
	}
}
void ArLive2Engine::DetachAudCapture(AudDevCaptureEvent*pEvent)
{
	if (!rtc::Thread::IsCurrent()) {
		rtc::Thread::Invoke<void>(RTC_FROM_HERE, rtc::Bind(&ArLive2Engine::DetachAudCapture, this, pEvent));
		return;
	}
	RTC_CHECK(rtc::Thread::IsCurrent());
	rtc::CritScope l(&cs_aud_capture_);
	if (map_aud_dev_capture_.find(pEvent) != map_aud_dev_capture_.end()) {
		map_aud_dev_capture_.erase(pEvent);
	}
}

void ArLive2Engine::AttachAudSpeaker(AudDevSpeakerEvent*pEvent)
{
	if (!rtc::Thread::IsCurrent()) {
		rtc::Thread::Invoke<void>(RTC_FROM_HERE, rtc::Bind(&ArLive2Engine::AttachAudSpeaker, this, pEvent));
		return;
	}
	RTC_CHECK(rtc::Thread::IsCurrent());
	bool needStartSpeaker = false;
	{
		rtc::CritScope l(&cs_aud_speaker_);
		if (map_aud_dev_speaker_.find(pEvent) == map_aud_dev_speaker_.end()) {
			if (map_aud_dev_speaker_.size() == 0) {
				needStartSpeaker = true;
			}
			map_aud_dev_speaker_[pEvent] = pEvent;
		}
	}
	if (needStartSpeaker) {
		if (!audio_device_ptr_->Playing()) {
			audio_device_ptr_->InitPlayout();
			if (audio_device_ptr_->StartPlayout() != 0) {
				audio_device_ptr_->StopPlayout();
				b_aud_ply_exception_ = true;
			}
		}
	}
}
void ArLive2Engine::DetachAudSpeaker(AudDevSpeakerEvent*pEvent)
{
	if (!rtc::Thread::IsCurrent()) {
		rtc::Thread::Invoke<void>(RTC_FROM_HERE, rtc::Bind(&ArLive2Engine::DetachAudSpeaker, this, pEvent));
		return;
	}
	RTC_CHECK(rtc::Thread::IsCurrent());
	bool needStopSpeaker = false;
	{
		rtc::CritScope l(&cs_aud_speaker_);
		if (map_aud_dev_speaker_.find(pEvent) != map_aud_dev_speaker_.end()) {
			map_aud_dev_speaker_.erase(pEvent);

			if (map_aud_dev_speaker_.size() == 0) {
				needStopSpeaker = true;
			}
		}
	}
	if (needStopSpeaker) {
		if (audio_device_ptr_->Playing()) {
			audio_device_ptr_->StopPlayout();
		}
	}
}
